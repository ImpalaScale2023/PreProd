ALTER PROCEDURE [dbo].[ReWeighing_InsertUpdate]
@IdCompany INT,
@IdReWeighing INT,  
@IdCompanyBranch INT,
@LotFrom INT,
@LotTo INT,
@IdClient INT,
@Weight INT,
@ReWeight INT,
@IdQuality INT,
@MaxWeighing INT,
@ReWeighingObs VARCHAR(50),
@SweepSoFlag BIT,
@Pila VARCHAR(20),
@IdProduct INT,
@Obs VARCHAR(50),
@IdStatus INT,
@IdCompanyAud INT,
@IdUserAud INT,
@Type INT,
@WmsReference VARCHAR(30),
@Error VARCHAR(MAX) OUTPUT
AS
BEGIN TRAN
BEGIN TRY
	SET @Error = ''

	IF @Weight < 0   
	BEGIN     
	;THROW 50002, '#VALID! the weight value cannot be less than or equal to zero', 1    
	END
	IF @Weight < @MaxWeighing   
	BEGIN     
	;THROW 50002, '#VALID! The weight cannot be less than the lot size', 1    
	END
	DECLARE @ClientBuyer DECIMAL(18, 2)
	--DECLARE @LotMax INT
	--SET @LotMax = ISNULL((SELECT MAX(LotTo) FROM ReWeighing 
	--	--WHERE IdQuality = @IdQuality AND IdClient = @IdClient AND IdCompany = @IdCompany AND (@IdReWeighing != IdReWeighing OR @IdReWeighing = 0)), 0)
	--	WHERE IdCompany = @IdCompany AND IdCompanyBranch = @IdCompanyBranch AND (@IdReWeighing != IdReWeighing OR @IdReWeighing = 0)), 0)
	SET @ClientBuyer = CAST(@Weight AS DECIMAL) / CAST(@MaxWeighing AS DECIMAL)
	--SET @LotFrom = @LotMax + 1
	--SET @LotTo = @LotMax + CEILING(@ClientBuyer)
	SET @LotFrom = 1
	SET @LotTo = CEILING(@ClientBuyer)
    IF @IdReWeighing = 0
    BEGIN
        SET NOCOUNT ON
        SELECT @IdReWeighing = ISNULL(MAX(IdReWeighing), 0) + 1 FROM ReWeighing
        SET NOCOUNT OFF
    
        INSERT INTO ReWeighing(IdCompany, IdReWeighing, LotFrom, LotTo, IdClient, [Weight], ReWeight, IdQuality, MaxWeighing,
					ClientBuyer, ReWeighigObs, SweepSoFlag, Pila, IdProduct, Obs, IdStatus, DeletedFlag, CreatedIdCompany, 
					CreatedIdUser, CreatedDate, IdCompanyBranch, [Type], WMSReference
        ) VALUES (@IdCompany, @IdReWeighing, @LotFrom, @LotTo, @IdClient, @Weight, @ReWeight, @IdQuality,
					 @MaxWeighing, @ClientBuyer, @ReWeighingObs, @SweepSoFlag, @Pila, @IdProduct, @Obs, @IdStatus, 0,
					 @IdCompanyAud, @IdUserAud, dbo.FechaUTC(@IdCompany, @IdCompanyBranch), @IdCompanyBranch, @Type, @WmsReference)
    END
    ELSE
    BEGIN
        UPDATE ReWeighing SET
		IdCompanyBranch = @IdCompanyBranch,
		LotFrom = @LotFrom,
		LotTo = @LotTo,
		IdClient = @IdClient,
		[Weight] = @Weight,
		ReWeight = @ReWeight,
		IdQuality = @IdQuality,
		MaxWeighing = @MaxWeighing,
		ClientBuyer = @ClientBuyer,
		ReWeighigObs = @ReWeighingObs,
		SweepSoFlag = @SweepSoFlag,
		Pila = @Pila,
		IdProduct = @IdProduct,
		[Type] = @Type,
		WMSReference = @WmsReference,
		IdStatus = @IdStatus,
		UpdatedIdCompany = @IdCompanyAud,	
		UpdatedIdUser = @IdUserAud,
		UpdatedDate = dbo.FechaUTC(@IdCompany, @IdCompanyBranch)
        WHERE  IdCompany = @IdCompany AND IdReWeighing = @IdReWeighing
    END

	IF (SELECT COUNT(*) FROM ReWeighing WHERE IdCompany = @IdCompany 
										AND IdCompanyBranch = @IdCompanyBranch 
										AND Pila = @Pila 
										AND DeletedFlag = 0) > 1
    BEGIN
        ROLLBACK TRAN
        SET @Error = '#VALID!' + 'The pila already exists'
    END
    ELSE
    BEGIN
        COMMIT TRAN
    END
END TRY
BEGIN CATCH
    ROLLBACK TRAN
    SET @Error = CONCAT('L�nea N�', ERROR_LINE(), ': ', ERROR_MESSAGE())
END CATCH
GO

-- EXEC dbo.ReWeighing_List 1, 1,0, '20220514', '20220614', 0, '212', 1,10
ALTER PROCEDURE [dbo].[ReWeighing_List]
@IdCompany INT,  
@IdCompanyBranch INT,
@TimeZone INT,
@InitialDate VARCHAR(8), --Formato yyyymmdd  
@FinalDate VARCHAR(8), --Formato yyyymmdd  
@IdStatus INT,
@Search VARCHAR(50),
@PageIndex INT,
@PageSize INT
AS
SET NOCOUNT ON
DECLARE @TotalElements INT

DECLARE @Base AS TABLE
(
IdReWeighing INT,
LotFrom INT,
LotTo INT,
Lotes VARCHAR(20),
IdClient INT,
Client VARCHAR(50),
[Weight] INT,
ReWeight INT,
IdQuality INT,
Quality VARCHAR(100),
MaxWeighing INT,
ClientBuyer DECIMAL(18, 2),
ReWeighigObs VARCHAR(50),
SweepSoFlag BIT,
Pila VARCHAR(20),
IdProduct INT,
CodProduct VARCHAR(40),
Obs VARCHAR(50),
DateStart VARCHAR(20),
DateEnd VARCHAR(20),
IdStatus INT,
[Status] VARCHAR(50),
CreatedCompany VARCHAR(100),
CreatedUser VARCHAR(100),
CreatedDate VARCHAR(20),
UpdatedCompany VARCHAR(100),
UpdatedUser VARCHAR(100),
UpdatedDate VARCHAR(20),
Progress DECIMAL(18, 2),
[Type] INT,
TypeDesc VARCHAR(100),
WmsReference VARCHAR(30),
IdStatusEdit INT
)
INSERT INTO @Base (IdReWeighing, LotFrom, LotTo, Lotes, IdClient, Client, [Weight], ReWeight, IdQuality, Quality, 
			MaxWeighing, ClientBuyer, ReWeighigObs, SweepSoFlag, Pila, IdProduct, CodProduct, Obs, DateStart, DateEnd, IdStatus, 
			[Status], CreatedCompany, CreatedUser, CreatedDate, UpdatedCompany, UpdatedUser, UpdatedDate, Progress,
			[Type], TypeDesc, WmsReference, IdStatusEdit)
SELECT
re.IdReWeighing,
re.LotFrom,
re.LotTo,
CASE WHEN re.LotFrom = re.LotTo THEN CAST(re.LotFrom AS VARCHAR) ELSE CONCAT(re.LotFrom, '-', re.LotTo) END AS Lotes,
re.IdClient,
cl.ClientNumber,
re.[Weight],
re.ReWeight,
re.IdQuality,
qu.[Description] as Quality,
re.MaxWeighing,
re.ClientBuyer,
re.ReWeighigObs,
re.SweepSoFlag,
re.Pila,
re.IdProduct,
pr.CodProduct,
re.Obs,
ISNULL(CONVERT(VARCHAR(10), re.DateStart, 120) + ' ' + CONVERT(VARCHAR(8), DATEADD(MINUTE, @TimeZone, re.DateStart), 108), '') AS DateStart,
ISNULL(CONVERT(VARCHAR(10), re.DateEnd, 120) + ' ' + CONVERT(VARCHAR(8), DATEADD(MINUTE, @TimeZone, re.DateEnd), 108), '') AS DateEnd,
re.IdStatus,
tblm.[Description] AS [Status],
us1.UserLogin AS CreatedUser,
com.CompanyName AS CreatedCompany,
CONVERT(VARCHAR(10), re.CreatedDate, 120) + ' ' + CONVERT(VARCHAR(8), DATEADD(MINUTE, @TimeZone, re.CreatedDate), 108) AS CreatedDate,
ISNULL(emp2.CompanyName, ' ') AS UpdatedCompany,
ISNULL(us2.UserLogin, ' ') AS UpdatedUser,
ISNULL(CONVERT(VARCHAR(10), re.UpdatedDate, 120) + ' ' + CONVERT(VARCHAR(8), DATEADD(MINUTE, @TimeZone, re.UpdatedDate), 108), ' ') AS UpdatedDate,
CONVERT(decimal(18, 2), CONVERT(DECIMAL(18, 2), [ReWeight] * 100) / CONVERT(decimal(18, 2), [Weight])),
ISNULL(re.[Type], 0),
tbTy.[Description] AS TypeDesc,
ISNULL(re.WmsReference, '') AS WmsReference,
ISNULL(re.IdStatusEdit, 0)
FROM ReWeighing re
INNER JOIN MasterTable tblm ON tblm.IdTable = 11 AND tblm.IdColumn = re.IdStatus AND tblm.IdColumn > 0
INNER JOIN MasterTable tbTy ON tbTy.IdTable = 25 AND tbTy.IdColumn = re.[Type] AND tbTy.IdColumn > 0
INNER JOIN Quality qu on qu.IdQuality = re.IdQuality AND qu.IdCompany = re.IdCompany
INNER JOIN Company com ON com.IdCompany = re.CreatedIdCompany
INNER JOIN [User] us1 ON us1.IdCompany = re.IdCompany AND us1.IdUser = re.CreatedIdUser
INNER JOIN Client cl ON cl.IdCompany = @IdCompany AND cl.IdClient = re.IdClient
INNER JOIN Product pr ON pr.IdCompany = @IdCompany AND pr.IdProduct = re.IdProduct
LEFT JOIN Company emp2 ON emp2.IdCompany = re.UpdatedIdCompany
LEFT JOIN [User] us2 ON us2.IdCompany = re.IdCompany AND us2.IdUser = re.UpdatedIdUser
WHERE re.IdCompany = @IdCompany AND re.IdCompanyBranch = @IdCompanyBranch
	AND (re.IdStatus = @IdStatus or @IdStatus = 0)
	AND re.DeletedFlag = 0
	AND (re.CreatedDate BETWEEN CONVERT(DATETIME, @InitialDate + ' 00:00:00') AND CONVERT(DATETIME, @FinalDate + ' 23:59:59'))  
	AND (re.pila LIKE '%' + @Search + '%' OR re.LotFrom LIKE '%' + @Search + '%' OR re.LotTo LIKE '%' + @Search + '%'
		OR cl.ClientNumber LIKE '%' + @Search + '%' OR tbTy.[Description] LIKE '%' + @Search + '%' OR pr.CodProduct LIKE '%' + @Search + '%'
		OR qu.[Description] LIKE '%' + @Search + '%' OR re.[Weight] LIKE '%' + @Search + '%' OR re.ReWeight LIKE '%' + @Search + '%'
		OR re.MaxWeighing LIKE '%' + @Search + '%' OR re.WmsReference LIKE '%' + @Search + '%' OR re.DateStart LIKE '%' + @Search + '%'
		OR re.DateEnd LIKE '%' + @Search + '%')

SELECT @TotalElements = COUNT(1) FROM @Base
SET NOCOUNT OFF

SELECT
IdReWeighing,
LotFrom,
LotTo,
Lotes,
IdClient,
Client,
[Weight],
ReWeight,
IdQuality,
Quality,
MaxWeighing,
ClientBuyer,
ReWeighigObs,
SweepSoFlag,
Pila,
IdProduct,
CodProduct,
Obs,
DateStart,
DateEnd,
IdStatus,
[Status],
CreatedCompany,
CreatedUser,
CreatedDate,
UpdatedCompany,
UpdatedUser,
UpdatedDate,
Progress,
[Type],
TypeDesc,
WmsReference,
IdStatusEdit,
@TotalElements AS TotalElements
FROM @Base
ORDER BY IdReWeighing DESC
OFFSET @PageSize * (@PageIndex - 1) ROWS
FETCH NEXT @PageSize ROWS ONLY
GO

--EXEC [dbo].[ReWeighingWeight_Delete] 1,1,3,1, 1, true
ALTER PROCEDURE  [dbo].[ReWeighingWeight_Delete]
@IdCompany INT,
@IdReWeighingWeight INT,
@IdReWeighing INT,
@IdUserAud INT ,
@IdCompanyAud INT,
@FlagAll BIT
AS
BEGIN TRY
	DECLARE @TotalNet INT, @TotalNetLot INT
	DECLARE @IdCompanyBranch INT
	SELECT @IdCompanyBranch = IdCompanyBranch FROM ReWeighingWeight WHERE IdCompany = @IdCompany AND IdReWeighingWeight = @IdReWeighingWeight	
	--SELECT @TotalNetLot=ISNULL(SUM(NetWeight),0) FROM ReWeighingWeight WHERE IdCompany = @IdCompany AND IdReWeighing = @IdReWeighing AND Lot = @CurrentLot AND DeletedFlag = 0
	IF (@FlagAll = 1)
	BEGIN
		UPDATE ReWeighingWeight SET
			DeletedFlag = 1,
			UpdatedIdCompany = @IdCompanyAud,
			UpdatedIdUser = @IdUserAud,
			UpdatedDate = dbo.FechaUTC(@IdCompany, @IdCompanyBranch)
		WHERE IdCompany = @IdCompany
		--AND IdReWeighingWeight = @IdReWeighingWeight 
		AND IdReWeighing = @IdReWeighing
		AND DeletedFlag = 0
	END
	ELSE
	BEGIN
		UPDATE	ReWeighingWeight SET
			DeletedFlag = 1,
			UpdatedIdCompany = @IdCompanyAud,
			UpdatedIdUser = @IdUserAud,
			UpdatedDate = dbo.FechaUTC(@IdCompany, @IdCompanyBranch)
		WHERE IdCompany = @IdCompany
		AND IdReWeighingWeight = @IdReWeighingWeight 
		AND IdReWeighing = @IdReWeighing
	END
	
	SELECT @TotalNet=ISNULL(SUM(NetWeight),0) FROM ReWeighingWeight WHERE IdCompany = @IdCompany AND IdReWeighing = @IdReWeighing AND DeletedFlag = 0
	UPDATE ReWeighing SET
	ReWeight = @TotalNet
	WHERE IdCompany = @IdCompany AND IdReWeighing = @IdReWeighing

	SELECT 1 AS Ok, '' AS [Message]
END TRY
BEGIN CATCH
    SELECT 0 AS Ok, CONCAT('L�nea N�', ERROR_LINE(), ': ', ERROR_MESSAGE()) AS [Message]
END CATCH
GO

ALTER PROCEDURE [dbo].[ReWeighingWeight_InsertUpdate]  
@IdCompany INT,  
@IdCompanyBranch INT,
@IdReWeighingWeight_OG INT,
@IdWeightType INT,
@IdReWeighingWeight INT,  
@IdReWeighing INT,  
@IdVehicle INT,  
@TruckNumber VARCHAR(20),  -- SI NO MANDA ''      
@TrailerNumber VARCHAR(20),  -- SI NO MANDA  ''    
@Weight INT,  
@Obs VARCHAR(100),  
@MemorizedTareFlag BIT,  
@IdCompanyAud INT,  
@IdUserAud INT,  
@ConfirmLotType INT,-- 0:ninguno 1:newlote 2:current lot,  
@IdBascule INT,
@Error VARCHAR(MAX) OUTPUT
AS  
BEGIN TRAN  
BEGIN TRY  
 DECLARE   
 @GrossWeight INT,   
 @TareWeight INT,   
 @NetWeight INT  
 DECLARE   
 @LotFrom INT,  
 @LotTo INT,  
 @LimitLot INT,  
 @LimitWeight INT,  
 @CurrentLot INT,  
 @IsLastLot BIT = 0,  
 @TotalNet INT, -- NETO TOTAL DE TODOS LOS LOTES  
 @TotalNetLot INT -- NETO TOTAL DE LOTE ACTUAL  
  
 DECLARE @Sequence INT,      
   @_ERROR VARCHAR(MAX)  
  
IF @IdVehicle = 0 AND TRIM(@TruckNumber) = '' AND TRIM(@TrailerNumber) = ''      
BEGIN       
	;THROW 50002, '#VALID! The Truck AND Trailer Number are empty', 1      
END  
IF @Weight <= 0     
BEGIN       
	;THROW 50002, '#VALID! The weight value cannot be less than or equal to zero', 1      
END    
 SELECT @LotFrom = LotFrom, @LotTo = LotTo, @LimitLot = MaxWeighing, @LimitWeight = [Weight] FROM ReWeighing WHERE IdCompany = @IdCompany AND IdReWeighing = @IdReWeighing AND DeletedFlag = 0 
 SELECT @CurrentLot =ISNULL(MAX(Lot),@LotFrom) FROM ReWeighingWeight WHERE IdCompany = @IdCompany AND IdReWeighing = @IdReWeighing AND DeletedFlag = 0  
 SELECT @TotalNet=ISNULL(SUM(NetWeight),0) FROM ReWeighingWeight WHERE IdCompany = @IdCompany AND IdReWeighing = @IdReWeighing AND DeletedFlag = 0  
 SELECT @TotalNetLot=ISNULL(SUM(NetWeight),0) FROM ReWeighingWeight WHERE IdCompany = @IdCompany AND IdReWeighing = @IdReWeighing AND Lot = @CurrentLot AND DeletedFlag = 0  
   
 IF @LotTo = @CurrentLot SET @IsLastLot = 1  
   
-- VEHICLE      
IF @IdVehicle = 0       
BEGIN       
	IF EXISTS (SELECT 1 FROM Vehicle WHERE IdCompany = @IdCompany  
									AND TruckNumber = @TruckNumber AND TrailerNumber = @TrailerNumber AND DeletedFlag = 0)      
	BEGIN      
	  SELECT @IdVehicle = IdVehicle       
	  FROM Vehicle WHERE IdCompany = @IdCompany       
	  AND TruckNumber = @TruckNumber AND TrailerNumber = @TrailerNumber AND DeletedFlag = 0      
	END      
	ELSE      
	BEGIN      
	  SELECT @IdVehicle = ISNULL(MAX(IdVehicle), 0) + 1 FROM Vehicle      
		INSERT INTO Vehicle(IdCompany, IdVehicle, RFID, IdVehicleConfiguration, TruckNumber, TruckLong, TruckWidth, TruckHigh,  
		TruckInscription, TruckTare, TruckBrand, TruckModel, TruckMotor, IdTrailerType,       
		TrailerNumber, TrailerLong, TrailerWidth, TrailerHigh, TrailerInscription, TrailerTare,      
		BonusFlag, BonusExpirationDate, BonusMaxGrossWeight, IdCarrier, IdDriver,      
		IdStatus, DeletedFlag, CreatedIdCompany, CreatedIdUser, CreatedDate, IdCompanyBranch)      
		VALUES (@IdCompany, @IdVehicle, '', NULL, @TruckNumber, 0, 0, 0,       
		'', 0, '', '', '', 1, @TrailerNumber, 0, 0, 0, '', 0, 0, dbo.FechaUTC(@IdCompany, @IdCompanyBranch), 0, NULL,      
		0, 1, 0, @IdCompanyAud, @IdUserAud, dbo.FechaUTC(@IdCompany, @IdCompanyBranch), @IdCompanyBranch)      
	END      
END      
	SET @Error = ''  

-- (2023-01-24) Edici�n de RE-PESO
IF @IdReWeighingWeight_OG != 0
BEGIN
	IF @IdWeightType = 1 -- Gross
	BEGIN
		SET @GrossWeight = @Weight
		SET @TareWeight = ISNULL((SELECT TareWeight FROM dbo.ReWeighingWeight
						  WHERE IdCompany = @IdCompany
						  AND IdCompanyBranch = @IdCompanyBranch
						  AND IdReWeighingWeight = @IdReWeighingWeight_OG), 0)
	END
	ELSE
	BEGIN
		SET @GrossWeight = ISNULL((SELECT GrossWeight FROM dbo.ReWeighingWeight
						  WHERE IdCompany = @IdCompany
						  AND IdCompanyBranch = @IdCompanyBranch
						  AND IdReWeighingWeight = @IdReWeighingWeight_OG), 0)
		SET @TareWeight = @Weight
	END

	SET @NetWeight = IIF(@GrossWeight = 0, 0, @GrossWeight - @TareWeight)
  
	UPDATE dbo.ReWeighingWeight SET      
	IdVehicle = @IdVehicle,  
	Lot = @CurrentLot,
	GrossWeight = @GrossWeight,
	TareWeight = @TareWeight,
	NetWeight = @NetWeight,   
	Obs = @Obs,    
	UpdatedIdCompany = @IdCompanyAud,   
	UpdatedIdUser = @IdUserAud,  
	UpdatedDate = dbo.FechaUTC(@IdCompany, @IdCompanyBranch),
	IdStatusEdit = IIF(@IdWeightType = 1, 2, 1)
	WHERE  IdCompany = @IdCompany
	AND IdReWeighing = @IdReWeighing
	AND IdReWeighingWeight = @IdReWeighingWeight_OG
	AND IdCompanyBranch = @IdCompanyBranch  
	AND DeletedFlag = 0  
  
	UPDATE dbo.ReWeighing SET  
	ReWeight = @TotalNet + @NetWeight,  
	DateEnd = dbo.FechaUTC(@IdCompany, @IdCompanyBranch),
	IdStatusEdit = IIF(@IdWeightType = 1, 2, 1)
	WHERE IdCompany = @IdCompany   
	AND IdReWeighing = @IdReWeighing  
	AND DeletedFlag = 0  
END
ELSE
BEGIN
IF @IdReWeighingWeight = 0
    BEGIN  
  ------ nuevo  
	IF EXISTS(SELECT 1 FROM ReWeighingWeight WHERE IdCompany = @IdCompany  
             AND IdCompanyBranch = @IdCompanyBranch  
             AND IdReWeighing = @IdReWeighing   
             AND GrossWeight = 0   
             AND IdVehicle = @IdVehicle   
             AND DeletedFlag = 0)  
	BEGIN       
	;THROW 50002, '#VALID! The vehicle already has a tare weight', 1      
	END  
  -----  
    SET NOCOUNT ON  
	SET @Sequence = ISNULL((SELECT MAX([Sequence]) FROM ReWeighingWeight       
	WHERE IdReWeighing = @IdReWeighing AND IdCompany = @IdCompany AND IdCompanyBranch = @IdCompanyBranch AND DeletedFlag=0),0) + 1      
        
        SELECT @IdReWeighingWeight = ISNULL(MAX(IdReWeighingWeight), 0) + 1 FROM ReWeighingWeight WHERE IdCompany = @IdCompany   
        SET NOCOUNT OFF        
  IF @MemorizedTareFlag = 0  
  BEGIN   
   INSERT INTO ReWeighingWeight(  
      IdCompany, IdReWeighingWeight, IdReWeighing, IdVehicle, Lot, GrossWeight, TareWeight, NetWeight, Obs,  
      TareDate, MemorizedTareFlag, IdStatusWeight, IdStatus, DeletedFlag, CreatedIdCompany,   
      CreatedIdUser, CreatedDate, IdCompanyBranch, InputIdBascule, [Sequence]  
   ) VALUES (  
       @IdCompany, @IdReWeighingWeight, @IdReWeighing, @IdVehicle, @CurrentLot, 0, @Weight, 0, @Obs,   
       dbo.FechaUTC(@IdCompany, @IdCompanyBranch), @MemorizedTareFlag, 1, 1, 0, @IdCompanyAud, @IdUserAud,   
       dbo.FechaUTC(@IdCompany, @IdCompanyBranch), @IdCompanyBranch, @IdBascule, @Sequence)  
  
   UPDATE ReWeighing SET  
    DateStart = dbo.FechaUTC(@IdCompany, @IdCompanyBranch),  
    DateEnd = dbo.FechaUTC(@IdCompany, @IdCompanyBranch)  
   WHERE IdCompany = @IdCompany AND IdReWeighing = @IdReWeighing AND IdStatus = 1  
   UPDATE ReWeighing SET  
    IdStatus = 2  
   WHERE IdCompany = @IdCompany AND IdReWeighing = @IdReWeighing  
     
  END  
  ELSE IF @MemorizedTareFlag = 1
  BEGIN  
   SET @TareWeight =ISNULL((select top 1 rewe.TareWeight from ReWeighingWeight rewe   
    where rewe.IdCompany = @IdCompany and rewe.IdVehicle = @IdVehicle  
    order by IdReWeighingWeight desc),0) 

	IF @TareWeight <= 0
	BEGIN
		BEGIN       
		;THROW 50002, '#VALID! The vehicle does not have a tare weight', 1      
  END 
	END
   SET @NetWeight = @Weight - @TareWeight  
  
   IF @NetWeight <= 0    
   BEGIN       
   ;THROW 50002, '#VALID! Gross Weight cannot be less than or equal to Tare Weight', 1      
   END  
   --IF @TotalNet + @NetWeight > @LimitWeight  
   --BEGIN  
   -- ;THROW 50002, '#VALID! The Limit has been exceeded', 1  
   --END  
  
   IF (@TotalNetLot + @NetWeight) > @LimitLot  
   BEGIN  
    IF @TotalNetLot * 0 > @LimitLot  
    BEGIN  
     SET @CurrentLot = @CurrentLot + 1  
    END  
    ELSE  
    BEGIN  
     IF @ConfirmLotType = 1  
     BEGIN  
      SET @CurrentLot = @CurrentLot + 1  
     END  
     ELSE IF @ConfirmLotType = 2  
     BEGIN   
      SET @CurrentLot=@CurrentLot  
     END  
     ELSE  
     BEGIN  
      SET @_ERROR = '#CONFIRM! There is a difference of '++CAST((@TotalNetLot + @NetWeight) - @LimitLot AS VARCHAR)+' Kg. It will generate new Lot '+CAST(@CurrentLot + 1 AS VARCHAR)  
      ;THROW 50003, @_ERROR, 1  
     END  
    END  
   END  
  
   INSERT INTO ReWeighingWeight(  
      IdCompany, IdReWeighingWeight, IdReWeighing, IdVehicle, Lot, GrossWeight, TareWeight, NetWeight, Obs, GrossDate,  
      TareDate, MemorizedTareFlag, IdStatusWeight, IdStatus, DeletedFlag, CreatedIdCompany,   
      CreatedIdUser, CreatedDate, IdCompanyBranch, InputIdBascule, OutputIdBascule, [Sequence]  
   ) VALUES (  
       @IdCompany, @IdReWeighingWeight, @IdReWeighing, @IdVehicle, @CurrentLot, @Weight, @TareWeight, @NetWeight, @Obs,  
       dbo.FechaUTC(@IdCompany, @IdCompanyBranch), dbo.FechaUTC(@IdCompany, @IdCompanyBranch), @MemorizedTareFlag,   
       2, 1, 0, @IdCompanyAud, @IdUserAud, dbo.FechaUTC(@IdCompany, @IdCompanyBranch), @IdCompanyBranch, @IdBascule,  
       @IdBascule, @Sequence)  
   UPDATE ReWeighing SET  
    DateStart = dbo.FechaUTC(@IdCompany, @IdCompanyBranch),  
    DateEnd = dbo.FechaUTC(@IdCompany, @IdCompanyBranch)  
   WHERE IdCompany = @IdCompany AND IdReWeighing = @IdReWeighing AND IdStatus = 1    
   UPDATE ReWeighing SET  
    ReWeight = @TotalNet + @NetWeight,  
    IdStatus = 2,  
    DateEnd = dbo.FechaUTC(@IdCompany, @IdCompanyBranch)  
   WHERE IdCompany = @IdCompany AND IdReWeighing = @IdReWeighing  
  END          
    END  
ELSE  ------------------
    BEGIN  
  ------ nuevo  
  IF NOT EXISTS(SELECT 1 FROM ReWeighingWeight WHERE IdCompany = @IdCompany   
             AND IdCompanyBranch = @IdCompanyBranch  
             AND IdReWeighing = @IdReWeighing  
             AND TareWeight > 0  
             AND GrossWeight = 0   
             AND IdVehicle = @IdVehicle   
             AND DeletedFlag = 0)  
  BEGIN       
  ;THROW 50002, '#VALID! The vehicle does not have a tare weight', 1      
  END  
  -----  
  --SELECT @TareWeight = TareWeight FROM ReWeighingWeight WHERE IdCompany = @IdCompany AND IdReWeighingWeight = @IdReWeighingWeight  
  SELECT @TareWeight = TareWeight FROM ReWeighingWeight WHERE IdCompany = @IdCompany AND IdCompanyBranch = @IdCompanyBranch AND IdVehicle = @IdVehicle AND GrossWeight = 0  
  SET @NetWeight = @Weight - @TareWeight 
    
  IF @NetWeight <= 0    
  BEGIN       
  ;THROW 50002, '#VALID! Gross Weight cannot be less than or equal to Tare Weight', 1      
  END  
  --IF @TotalNet + @NetWeight > @LimitWeight  
  --BEGIN  
  -- ;THROW 50002, '#VALID! The Limit has been exceeded', 1  
  --END  
  
  IF (@TotalNetLot + @NetWeight) > @LimitLot
  BEGIN  
   IF @TotalNetLot * 0 > @LimitLot  
   BEGIN  
    SET @CurrentLot = @CurrentLot + 1  
   END  
   ELSE  
   BEGIN  
    IF @ConfirmLotType = 1  
    BEGIN  
     SET @CurrentLot = @CurrentLot + 1  
    END  
    ELSE IF @ConfirmLotType = 2  
    BEGIN   
     SET @CurrentLot=@CurrentLot  
    END  
    ELSE  
    BEGIN  
      SET @_ERROR = '#CONFIRM! There is a difference of '++CAST((@TotalNetLot + @NetWeight) - @LimitLot AS VARCHAR)+' Kg. It will generate new Lot '+CAST(@CurrentLot + 1 AS VARCHAR)  
     ;THROW 50003, @_ERROR, 1  
    END  
   END  
  END  
  
  UPDATE ReWeighingWeight SET      
  IdReWeighing = @IdReWeighing,   
  IdVehicle = @IdVehicle,  
  Lot = @CurrentLot,  
  GrossWeight = @Weight,   
  NetWeight = @NetWeight,   
  Obs = @Obs,   
  GrossDate = dbo.FechaUTC(@IdCompany, @IdCompanyBranch),    
  MemorizedTareFlag = @MemorizedTareFlag,   
  IdStatusWeight = 2,  
  OutputIdBascule = @IdBascule,
  IdStatus = 1,  
  UpdatedIdCompany = @IdCompanyAud,   
  UpdatedIdUser = @IdUserAud,  
  UpdatedDate = dbo.FechaUTC(@IdCompany, @IdCompanyBranch)  
  WHERE  IdCompany = @IdCompany
   AND IdReWeighing = @IdReWeighing
   --AND IdReWeighingWeight = @IdReWeighingWeight
   AND IdCompanyBranch = @IdCompanyBranch  
   AND IdVehicle = @IdVehicle  
   AND GrossWeight = 0  
   AND DeletedFlag = 0  
  
  UPDATE ReWeighing SET  
  ReWeight = @TotalNet + @NetWeight,  
  DateEnd = dbo.FechaUTC(@IdCompany, @IdCompanyBranch)  
  WHERE IdCompany = @IdCompany   
  AND IdReWeighing = @IdReWeighing  
  AND DeletedFlag = 0  
    END
END
  
    COMMIT TRAN  
END TRY  
BEGIN CATCH  
    ROLLBACK TRAN  
    SET @Error = CONCAT('L�nea N�', ERROR_LINE(), ': ', ERROR_MESSAGE())  
END CATCH
GO

ALTER PROCEDURE [dbo].[ReWeighingWeight_Ticket]
@IdCompany INT,
@TimeZone INT,
@IdReWeighing INT,
@IdReWeighingWeight INT,
@IdStatus INT
AS
DECLARE @IdCompanyBranch INT = (SELECT IdCompanyBranch FROM ReWeighingWeight 
														WHERE IdReWeighingWeight = @IdReWeighingWeight 
														AND IdReWeighing = @IdReWeighing)
DECLARE @FechaImpresion DATETIME = dbo.FechaUTC(@IdCompany, @IdCompanyBranch)
--DECLARE @IdWeighingCycle INT
--SELECT @IdWeighingCycle = IdWeighingCycle FROM Weighing WHERE IdCompany = @IdCompany AND IdWeighing = @IdWeighing

IF @IdStatus = 1
BEGIN
	SELECT
	CONCAT(CONVERT(VARCHAR(10), @FechaImpresion, 103), ' ', CONVERT(VARCHAR(8), DATEADD(MINUTE, @TimeZone, @FechaImpresion), 108)) AS FechaImpresion,
		FORMAT(DATEADD(MINUTE, @TimeZone, @FechaImpresion) , 'yyyyMMddHHmmss') AS FechaImpresion2,
	cb.CompanyBranch AS ImpalaTerminals,
	ve.TruckNumber AS TruckPlate,
	ve.TrailerNumber AS TrailerPlate,
	rw.Pila AS Pila,
	ISNULL(CONVERT(VARCHAR(10), rww.TareDate, 120), '') AS Fecha,
	ISNULL(CONVERT(VARCHAR(8), DATEADD(MINUTE, @TimeZone, rww.TareDate), 108), '') AS Hora,
	ve.TrailerNumber AS Carreta,
	rw.IdQuality,
	qu.[Description] AS Quality,
	ISNULL(rw.WMSReference, '') AS WMSReference,
	rw.IdProduct,
	pr.CodProduct AS Product,
	ISNULL(cl.BusinessName, '') AS Productor,
	'' AS Descarga,
	ISNULL(rww.[Sequence], 0) AS nrCamion,
	rww.Lot,
	rww.TareWeight
	FROM ReWeighingWeight rww
	INNER JOIN CompanyBranch cb ON cb.IdCompany = rww.IdCompany AND cb.IdCompanyBranch = rww.IdCompanyBranch
	INNER JOIN ReWeighing rw ON rw.IdCompany = rww.IdCompany AND rw.IdCompanyBranch = rww.IdCompanyBranch AND rw.IdReWeighing = rww.IdReWeighing
	INNER JOIN Vehicle ve ON ve.IdCompany = rww.IdCompany AND ve.IdCompanyBranch = rww.IdCompanyBranch AND ve.IdVehicle = rww.IdVehicle
	INNER JOIN Quality qu ON qu.IdCompany = rww.IdCompany AND qu.IdCompanyBranch = rww.IdCompanyBranch AND qu.IdQuality = rw.IdQuality
	INNER JOIN Client cl ON cl.IdCompany = rww.IdCompany AND cl.IdCompanyBranch = rww.IdCompanyBranch AND cl.IdClient = rw.IdClient
	INNER JOIN Product pr ON pr.IdCompany = rww.IdCompany AND pr.IdCompanyBranch = rww.IdCompanyBranch AND pr.IdProduct = rw.IdProduct
	WHERE rww.IdCompany = @IdCompany 
		AND rww.IdReWeighingWeight = @IdReWeighingWeight 
		AND rww.IdReWeighing = @IdReWeighing
END
ELSE  IF @IdStatus = 2
BEGIN
	SELECT
	CONCAT(CONVERT(VARCHAR(10), @FechaImpresion, 103), ' ', CONVERT(VARCHAR(8), DATEADD(MINUTE, @TimeZone, @FechaImpresion), 108)) AS FechaImpresion,
	FORMAT(DATEADD(MINUTE, @TimeZone, @FechaImpresion) , 'yyyyMMddHHmmss') AS FechaImpresion2,
	cb.CompanyBranch AS ImpalaTerminals,
	'' AS Descarga,
	'Re-Peso' AS TypeOperation,
	ve.TruckNumber AS TruckPlate,
	ve.TrailerNumber AS TrailerPlate,
	rw.Pila AS Pila,
	rw.IdProduct,
	pr.DescProduct AS Product,
	ISNULL(cl.BusinessName, '') AS Productor,
	rw.IdQuality,
	qu.[Description] AS Quality,
	ISNULL(rw.WMSReference, '') AS WMSReference,
	rww.Obs,
	ISNULL(baI.Bascule, '') AS InputBascule,
	ISNULL(baO.Bascule, '') AS OutputBascule,
	ISNULL(CONVERT(VARCHAR(10), rww.GrossDate, 120), '') AS InputDate,
	ISNULL(CONVERT(VARCHAR(8), DATEADD(MINUTE, @TimeZone, rww.GrossDate), 108), '') AS InputHour,
	ISNULL(CONVERT(VARCHAR(10), rww.TareDate, 120), '') AS OutputDate,
	ISNULL(CONVERT(VARCHAR(8), DATEADD(MINUTE, @TimeZone, rww.TareDate), 108), '') AS OutputHour,
	rww.GrossWeight,
	rww.TareWeight,
	rww.NetWeight,
	ISNULL(rww.[Sequence], 0) AS nrCamion,
	rww.Lot
	FROM ReWeighingWeight rww
	INNER JOIN CompanyBranch cb ON cb.IdCompany = rww.IdCompany AND cb.IdCompanyBranch = rww.IdCompanyBranch
	INNER JOIN ReWeighing rw ON rw.IdCompany = rww.IdCompany AND rw.IdCompanyBranch = rww.IdCompanyBranch AND rw.IdReWeighing = rww.IdReWeighing
	INNER JOIN Vehicle ve ON ve.IdCompany = rww.IdCompany AND ve.IdCompanyBranch = rww.IdCompanyBranch AND ve.IdVehicle = rww.IdVehicle
	INNER JOIN Quality qu ON qu.IdCompany = rww.IdCompany AND qu.IdCompanyBranch = rww.IdCompanyBranch AND qu.IdQuality = rw.IdQuality
	INNER JOIN Client cl ON cl.IdCompany = rww.IdCompany AND cl.IdCompanyBranch = rww.IdCompanyBranch AND cl.IdClient = rw.IdClient
	INNER JOIN Product pr ON pr.IdCompany = rww.IdCompany AND pr.IdCompanyBranch = rww.IdCompanyBranch AND pr.IdProduct = rw.IdProduct
	LEFT JOIN Bascule baI ON baI.IdCompany = rww.IdCompany AND baI.IdCompanyBranch = rww.IdCompanyBranch AND baI.IdBascule = rww.InputIdBascule
	LEFT JOIN Bascule baO ON baO.IdCompany = rww.IdCompany AND baO.IdCompanyBranch = rww.IdCompanyBranch AND baO.IdBascule = rww.OutputIdBascule
	WHERE rww.IdCompany = @IdCompany 
		AND rww.IdReWeighingWeight = @IdReWeighingWeight 
		AND rww.IdReWeighing = @IdReWeighing
END
GO

ALTER PROCEDURE [dbo].[Vehicle_InsertUpdate]
@IdCompany INT,
@IdCompanyBranch INT,
@IdVehicle INT,
@RFID VARCHAR(200), -- Ocultar en FrontEnd y enviar ''
@IdVehicleConfiguration INT,
@TruckNumber VARCHAR(20),
@TruckLong DECIMAL(18, 2),
@TruckWidth DECIMAL(18, 2),
@TruckHigh DECIMAL(18, 2),
@TruckInscription VARCHAR(30), --Codigo de la tajeta de propiedad de Tracto
@TruckTare INT,
@TruckBrand VARCHAR(30),
@TruckModel VARCHAR(30),
@TruckMotor VARCHAR(20),
@IdTrailerType INT,
@TrailerNumber VARCHAR(20),
@TrailerLong DECIMAL(18, 2),
@TrailerWidth DECIMAL(18, 2),
@TrailerHigh DECIMAL(18, 2),
@TrailerInscription VARCHAR(30),  --Codigo de la tajeta de propiedad de Acoplado
@TrailerTare INT,
@BonusFlag BIT,
@BonusExpirationDate VARCHAR(8),
@BonusMaxGrossWeight INT,
@IdCarrier INT,
@IdDriver INT,
@IdStatus INT,
@IdCompanyAud INT,
@IdUserAud INT,
@TBonus dbo.TBonus READONLY,
@Error VARCHAR(MAX) OUTPUT
AS
BEGIN TRAN
BEGIN TRY
DECLARE @IdBonificacionMax int
	IF @IdVehicle = 0
	BEGIN
		SELECT @IdVehicle = ISNULL(MAX(IdVehicle),0)+1 FROM Vehicle where IdCompany = @IdCompany
		INSERT INTO Vehicle
		(IdCompany, IdCompanyBranch, IdVehicle, RFID, IdVehicleConfiguration, TruckNumber, TruckLong, TruckWidth, TruckHigh, TruckInscription, 
		TruckTare, TruckBrand, TruckModel, TruckMotor, IdTrailerType, TrailerNumber, TrailerLong, TrailerWidth, TrailerHigh, 
		TrailerInscription, TrailerTare, BonusFlag, BonusExpirationDate, BonusMaxGrossWeight, IdCarrier, IdDriver, IdStatus, DeletedFlag, 
		CreatedIdCompany, CreatedIdUser, CreatedDate)
		VALUES 
		(@IdCompany, @IdCompanyBranch, @IdVehicle, @RFID, @IdVehicleConfiguration, @TruckNumber, @TruckLong, @TruckWidth, @TruckHigh, @TruckInscription,
		@TruckTare, @TruckBrand, @TruckModel, @TruckMotor, @IdTrailerType, @TrailerNumber, @TrailerLong, @TrailerWidth, @TrailerHigh,
		@TrailerInscription, @TrailerTare, @BonusFlag, @BonusExpirationDate, @BonusMaxGrossWeight, @IdCarrier, @IdDriver, @IdStatus, 0, 
		@IdCompanyAud, @IdUserAud, dbo.FechaUTC(@IdCompany, @IdCompanyBranch))
	END
	ELSE
	BEGIN
		UPDATE Vehicle SET
		RFID = @RFID,
		IdCompanyBranch = @IdCompanyBranch,
		IdVehicleConfiguration = @IdVehicleConfiguration,
		TruckNumber = @TruckNumber,
		TruckLong = @TruckLong,
		TruckWidth = @TruckWidth,
		TruckHigh = @TruckHigh,
		TruckInscription = @TruckInscription,
		TruckTare = @TruckTare,
		TruckBrand = @TruckBrand,
		TruckModel = @TruckModel,
		TruckMotor = @TruckMotor,
		IdTrailerType = @IdTrailerType,
		TrailerNumber = @TrailerNumber,
		TrailerLong = @TrailerLong,
		TrailerWidth = @TrailerWidth,
		TrailerHigh = @TrailerHigh,
		TrailerInscription = @TrailerInscription,
		TrailerTare = @TrailerTare,
		BonusFlag = @BonusFlag,
		BonusExpirationDate = @BonusExpirationDate,
		BonusMaxGrossWeight = @BonusMaxGrossWeight,
		IdCarrier = @IdCarrier,
		IdDriver = @IdDriver,
		IdStatus = @IdStatus,
		DeletedFlag = 0, 
		UpdatedIdUser = @IdUserAud, 
		UpdatedDate = dbo.FechaUTC(@IdCompany, @IdCompanyBranch), 
		UpdatedIdCompany = @IdCompanyAud
		WHERE IdCompany = @IdCompany
		AND IdVehicle = @IdVehicle
	END

	
	IF @BonusFlag = 1
	BEGIN
	DELETE FROM VehicleBonus WHERE IdVehicle = @IdVehicle
		SELECT @IdBonificacionMax = ISNULL( MAX(IdBonus),0) +1 from VehicleBonus where IdCompany = @IdCompany
		INSERT INTO VehicleBonus
		(IdCompany, IdBonus, IdVehicle, IdAxleSet, Limit, IdStatus, DeletedFlag, CreatedIdCompany, CreatedIdUser, 
		CreatedDate)
		SELECT
		@IdCompany, 
		ROW_NUMBER() OVER(ORDER BY (SELECT NULL))+@IdBonificacionMax,
		@IdVehicle, 
		tbl.idAxleSet, 
		tbl.Limit,
		@IdStatus,
		0,
		@IdCompanyAud,
		@IdUserAud,
		dbo.FechaUTC(@IdCompany, @IdCompanyBranch)
		FROM @TBonus tbl
	END	
	
	IF (SELECT COUNT(*) FROM Vehicle 
	WHERE IdCompany = @IdCompany
	AND IdCompanyBranch = @IdCompanyBranch
	AND TRIM(TruckNumber + TrailerNumber) = TRIM(@TruckNumber + @TrailerNumber) 
	AND DeletedFlag = 0) > 1
	BEGIN
        --SET @Error = '#VALID!' + 'The TruckNumber already exists'
		;THROW 50002, '#VALID! The TruckNumber already exists', 1
	END

COMMIT TRAN
END TRY
BEGIN CATCH
	ROLLBACK TRAN
	SET @Error = CONCAT('L�nea N�', ERROR_LINE(), ': ', ERROR_MESSAGE())
END CATCH
GO

-- EXEC dbo.Vehicle_List 1,1,1,5,'',1,9
ALTER PROCEDURE [dbo].[Vehicle_List]
@IdCompany INT,
@IdCompanyBranch INT,
@IdStatus INT,
@TimeZone INT,
@Search VARCHAR(50),
@PageIndex    INT,
@PageSize    INT
AS

SET NOCOUNT ON
DECLARE @TotalElements INT

DECLARE @Base AS TABLE
(IdFila INT IDENTITY PRIMARY KEY,
IdVehicle INT,
RFID VARCHAR(200) NULL,
IdVehicleConfiguration INT NULL,
VehicleType VARCHAR(20),
TruckNumber VARCHAR(20),
TruckLong DECIMAL(18, 2),
TruckWidth DECIMAL(18, 2),
TruckHigh DECIMAL(18, 2),
TruckInscription VARCHAR(30),
TruckTare INT,
TruckBrand VARCHAR(30),
TruckModel VARCHAR(30),
TruckMotor VARCHAR(20),
IdTrailerType INT,
TrailerType VARCHAR(100),
TrailerNumber VARCHAR(20),
TrailerLong DECIMAL(18, 2),
TrailerWidth DECIMAL(18, 2),
TrailerHigh DECIMAL(18, 2),
TrailerInscription VARCHAR(30),
TrailerTare INT,
BonusFlag BIT,
BonusExpirationDate VARCHAR(21),
BonusMaxGrossWeight INT,
IdCarrier INT,
Carrier VARCHAR(100),
IdDriver INT,
Driver VARCHAR(50),
IdStatus INT,
[Status] VARCHAR(100),
CreatedCompany VARCHAR(100),
CreatedUser VARCHAR(100),
CreatedDate VARCHAR(20),
UpdatedCompany VARCHAR(100) NULL,
UpdatedUser VARCHAR(100) NULL,
UpdatedDate VARCHAR(20) NULL
)
INSERT INTO @Base 
(IdVehicle, RFID, IdVehicleConfiguration, VehicleType, TruckNumber, TruckLong, TruckWidth, TruckHigh, TruckInscription, TruckTare, 
TruckBrand, TruckModel, TruckMotor, IdTrailerType, TrailerType, TrailerNumber, TrailerLong, TrailerWidth, TrailerHigh, TrailerInscription,
TrailerTare, BonusFlag, BonusExpirationDate, BonusMaxGrossWeight, IdCarrier, Carrier, IdDriver, Driver, IdStatus, [Status], 
CreatedCompany, CreatedUser, CreatedDate, UpdatedCompany, UpdatedUser, UpdatedDate)
SELECT
ve.IdVehicle,
ve.RFID,
ISNULL(ve.IdVehicleConfiguration, 0) AS IdVehicleConfiguration,
ISNULL(vety.VehicleType, '') AS VehicleType,
ve.TruckNumber,
ve.TruckLong,
ve.TruckWidth,
ve.TruckHigh,
ISNULL(ve.TruckInscription, '') AS TruckInscription,
ISNULL(ve.TruckTare, 0) AS TruckTare,
ve.TruckBrand,
ve.TruckModel,
ve.TruckMotor,
ve.IdTrailerType,
tire1.[Description] AS TrailerType,
ve.TrailerNumber,
ISNULL(ve.TrailerLong, 0) AS TrailerLong,
ISNULL(ve.TrailerWidth, 0) AS TrailerWidth,
ISNULL(ve.TrailerHigh, 0) AS TrailerHigh,
ISNULL(ve.TrailerInscription, '') AS TrailerInscription,
ISNULL(ve.TrailerTare, 0) AS TrailerTare,
ve.BonusFlag,
CONVERT(VARCHAR(10), ve.BonusExpirationDate, 120) AS BonusExpirationDate,
ve.BonusMaxGrossWeight,
ISNULL(ve.IdCarrier, 0) AS IdCarrier,
ISNULL(tra.Carrier, '') AS Carrier,
ve.IdDriver,
ISNULL(dr.Driver, '') AS Driver,
ve.IdStatus,
tblm.[Description] AS [Status],
emp1.CompanyName AS CreatedCompany,
us1.UserLogin AS CreatedUser,
CONVERT(VARCHAR(10), ve.CreatedDate, 120) + ' ' + CONVERT(VARCHAR(8), DATEADD(MINUTE, @TimeZone, ve.CreatedDate), 108) AS CreatedDate,
ISNULL(emp2.CompanyName, ' ') AS UpdatedCompany,
ISNULL(us2.UserLogin, ' ') AS UpdatedUser,
ISNULL(CONVERT(VARCHAR(10), ve.UpdatedDate, 120) + ' ' + CONVERT(VARCHAR(8), DATEADD(MINUTE, @TimeZone, ve.UpdatedDate), 108), ' ') AS UpdatedDate
FROM Vehicle ve
INNER JOIN MasterTable tblm ON tblm.IdCompany = ve.IdCompany AND tblm.IdTable = 1 AND tblm.IdColumn = ve.IdStatus AND tblm.IdColumn > 0
LEFT JOIN VehicleType vety ON vety.IdCompany = ve.IdCompany AND vety.IdVehicleType = ve.IdVehicleConfiguration
LEFT JOIN Driver dr ON ve.IdCompany = dr.IdCompany AND ve.IdDriver = dr.IdDriver
LEFT JOIN Carrier tra ON tra.IdCompany = ve.IdCompany AND tra.IdCarrier = ve.IdCarrier
LEFT JOIN MasterTable tire1 ON tire1.IdCompany = ve.IdCompany AND tire1.IdTable = 14 AND tire1.IdColumn = ve.IdTrailerType
INNER JOIN Company emp1 ON emp1.IdCompany = ve.CreatedIdCompany
INNER JOIN [User] us1 ON us1.IdCompany = ve.IdCompany AND us1.IdUser = ve.CreatedIdUser
LEFT JOIN Company emp2 ON emp2.IdCompany = ve.UpdatedIdCompany
LEFT JOIN [User] us2 ON us2.IdCompany = ve.IdCompany AND us2.IdUser = ve.UpdatedIdUser
WHERE ve.IdCompany = @IdCompany AND ve.DeletedFlag = 0 AND ve.IdCompanyBranch = @IdCompanyBranch
AND (ve.IdStatus = @IdStatus or @IdStatus = 0)
AND (ve.TruckNumber LIKE '%' + @Search + '%' OR ve.TrailerNumber LIKE '%' + @Search + '%' OR vety.VehicleType LIKE '%' + @Search + '%' 
	 OR ve.truckLong LIKE '%' + @Search + '%' OR ve.truckWidth LIKE '%' + @Search + '%' OR ve.truckHigh LIKE '%' + @Search + '%'
     OR ve.truckBrand LIKE '%' + @Search + '%' OR ve.truckModel LIKE '%' + @Search + '%' OR ve.truckMotor LIKE '%' + @Search + '%'
     OR tire1.[Description] LIKE '%' + @Search + '%' OR ve.bonusFlag LIKE '%' + @Search + '%' OR ve.bonusExpirationDate LIKE '%' + @Search + '%'
     OR ve.bonusMaxGrossWeight LIKE '%' + @Search + '%' OR tra.carrier LIKE '%' + @Search + '%' OR dr.driver LIKE '%' + @Search + '%')

SELECT @TotalElements = COUNT(*) FROM @Base
SELECT
IdVehicle,
RFID,
IdVehicleConfiguration,
VehicleType,
IdDriver,
Driver,
TruckNumber,
TruckLong,
TruckWidth,
TruckHigh,
TruckInscription,
TruckTare,
TruckBrand,
TruckModel,
TruckMotor,
IdTrailerType,
TrailerType,
TrailerNumber,
TrailerLong,
TrailerWidth,
TrailerHigh,
TrailerInscription,
TrailerTare,
BonusFlag,
BonusExpirationDate,
BonusMaxGrossWeight,
IdCarrier,
Carrier,
IdDriver,
Driver,
IdStatus,
[Status],
CreatedCompany,
CreatedUser,
CreatedDate,
UpdatedCompany,
UpdatedUser,
UpdatedDate,
@TotalElements AS TotalElements
FROM @Base
ORDER BY IdVehicle ASC
OFFSET @PageSize * (@PageIndex - 1) ROWS
FETCH NEXT @PageSize ROWS ONLY
GO

--EXEC [dbo].[Vehicle_PopUp] 1, '', '', 1, 10
ALTER PROCEDURE [dbo].[Vehicle_PopUp]
@IdCompanyBranch INT,
@IdOutbound VARCHAR(20),
@Search VARCHAR(200),
@PageIndex INT,
@PageSize INT
AS
SET NOCOUNT ON

--#Weighing
IF OBJECT_ID('tempdb.dbo.#Weighing') IS NOT NULL
BEGIN
  TRUNCATE TABLE dbo.#Weighing;
END
ELSE
BEGIN
	CREATE TABLE dbo.#Weighing(
		[Id] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY CLUSTERED,
		[IdCompany] [int] NOT NULL,
		[IdWeighing] [int] NOT NULL,
		[IdVehicle] [int] NOT NULL,
		)

	CREATE NONCLUSTERED INDEX [IX_TmpWeighing_IdVehicle] ON dbo.#Weighing
	(
		[IdCompany] ASC,
		[IdVehicle] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
END



INSERT INTO dbo.#Weighing (IdCompany, IdWeighing, IdVehicle)
SELECT 
we.IdCompany,
we.IdWeighing,
we.IdVehicle 
FROM dbo.Weighing we 
WHERE we.DeletedFlag = 0
AND (
	(we.IdStatus < 3 AND we.IdWeighingCycle = 1)
	OR
	(we.IdStatus < 2 AND we.IdWeighingCycle = 2)
)


--#Vehicle
IF OBJECT_ID('tempdb.dbo.#Vehicle') IS NOT NULL
BEGIN
  TRUNCATE TABLE dbo.#Vehicle;
END
ELSE
BEGIN
CREATE TABLE dbo.#Vehicle(
	[Id] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY CLUSTERED,
	[IdCompany] [int] NOT NULL,
	[IdVehicle] [int] NOT NULL,
	)
END

INSERT INTO dbo.#Vehicle
(IdCompany, IdVehicle)
SELECT
ve.IdCompany,
ve.IdVehicle
FROM dbo.Vehicle ve
INNER JOIN MasterTable tblm ON tblm.IdCompany = ve.IdCompany AND tblm.IdTable = 1 AND tblm.IdColumn = ve.IdStatus AND tblm.IdColumn > 0
LEFT JOIN VehicleType vety ON vety.IdCompany = ve.IdCompany AND vety.IdVehicleType = ve.IdVehicleConfiguration
LEFT JOIN Driver dr ON ve.IdCompany = dr.IdCompany AND ve.IdDriver = dr.IdDriver
LEFT JOIN Carrier tra ON tra.IdCompany = ve.IdCompany AND tra.IdCarrier = ve.IdCarrier
INNER JOIN MasterTable tire1 ON tire1.IdCompany = ve.IdCompany AND tire1.IdTable = 14 AND tire1.IdColumn = ve.IdTrailerType
WHERE NOT EXISTS (SELECT IdVehicle FROM dbo.#Weighing we 
			WHERE ve.IdCompany = we.IdCompany
				AND ve.IdVehicle = we.IdVehicle)
AND(
        ve.TruckNumber LIKE '%' + @Search + '%' OR ve.TruckInscription LIKE '%' + @Search + '%'
		OR ve.TruckBrand LIKE '%' + @Search + '%' OR ve.TruckModel LIKE '%' + @Search + '%' 
        OR ve.TrailerNumber LIKE '%' + @Search + '%' OR ve.TrailerInscription LIKE '%' + @Search + '%'
		OR dr.Driver LIKE '%' + @Search + '%' OR tra.Carrier LIKE '%' + @Search + '%' OR tire1.[Description] LIKE '%' + @Search + '%'
    )
AND ve.DeletedFlag = 0 
AND ve.IdCompanyBranch = @IdCompanyBranch
ORDER BY ve.TruckNumber ASC, ve.TrailerNumber ASC

DECLARE @TotalElements INT
SELECT @TotalElements = COUNT(1) FROM dbo.#Vehicle

SET NOCOUNT OFF
SELECT
ve.IdVehicle,
ve.RFID,
isnull(ve.IdVehicleConfiguration,0) IdVehicleConfiguration,
isnull(vety.VehicleType,'') VehicleType,
ve.TruckNumber,
ve.TruckLong,
ve.TruckWidth,
ve.TruckHigh,
ve.TruckInscription,
ve.TruckTare,
ve.TruckBrand,
ve.TruckModel,
ve.TruckMotor,
ve.IdTrailerType,
tire1.[Description] AS TrailerType,
ve.TrailerNumber,
ve.TrailerLong,
ve.TrailerWidth,
ve.TrailerHigh,
ve.TrailerInscription,
ve.TrailerTare,
ve.BonusFlag,
CONVERT(VARCHAR(10), ve.BonusExpirationDate, 120) AS BonusExpirationDate,
ve.BonusMaxGrossWeight,
ISNULL(ve.IdCarrier, 0) AS IdCarrier,
ISNULL(tra.Carrier, '') AS Carrier,
ve.IdDriver,
ISNULL(dr.Driver, '') AS Driver,
ISNULL(dr.LicenseNumber, '') AS LicenseNumber,
ISNULL((select top 1 rewe.TareWeight from ReWeighingWeight rewe 
		where rewe.IdCompany = ve.idcompany and rewe.IdVehicle = ve.IdVehicle
		order by IdReWeighingWeight desc),0) as LastTareReweight,
ve.IdStatus,
tblm.[Description] AS [Status],
@TotalElements AS TotalElement
FROM dbo.#Vehicle tmve
INNER JOIN dbo.Vehicle ve ON tmve.IdCompany = ve.IdCompany AND tmve.IdVehicle = ve.IdVehicle
INNER JOIN MasterTable tblm ON tblm.IdCompany = ve.IdCompany AND tblm.IdTable = 1 AND tblm.IdColumn = ve.IdStatus AND tblm.IdColumn > 0
LEFT JOIN VehicleType vety ON vety.IdCompany = ve.IdCompany AND vety.IdVehicleType = ve.IdVehicleConfiguration
LEFT JOIN Driver dr ON ve.IdCompany = dr.IdCompany AND ve.IdDriver = dr.IdDriver
LEFT JOIN Carrier tra ON tra.IdCompany = ve.IdCompany AND tra.IdCarrier = ve.IdCarrier
INNER JOIN MasterTable tire1 ON tire1.IdCompany = ve.IdCompany AND tire1.IdTable = 14 AND tire1.IdColumn = ve.IdTrailerType
ORDER BY ve.TruckNumber ASC, ve.TrailerNumber ASC
OFFSET @PageSize * (@PageIndex - 1) ROWS
FETCH NEXT @PageSize ROWS ONLY
GO

