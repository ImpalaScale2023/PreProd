ALTER TABLE [dbo].[Bascule] 
DROP COLUMN [FlagActiveCardReader],
[FlagCardReader]

GO

ALTER TABLE [dbo].[ReWeighing]
DROP COLUMN [MaxWeightTolerance],
[BatchSize],
[BatchSizeTolerance],
[IdPrinter],
[BatchSizeAcumulate]

GO

ALTER TABLE [dbo].[Vehicle]
DROP COLUMN [TruckTareTolerance],
[TruckMaxGrossWeight],
[TrailerTareTolerance]