DROP PROCEDURE [dbo].[Bascule_Update_FlagCardReader]

GO

DROP PROCEDURE [dbo].[Card_InsertUpdate]

GO

DROP PROCEDURE [dbo].[Card_List]

GO

DROP PROCEDURE [dbo].[CardId_Delete]

GO

DROP PROCEDURE [dbo].[ReWeghingWeight_Cancel]

GO

DROP PROCEDURE [dbo].[ReWeighingWeight_ReportTruck_ V2]

GO

DROP PROCEDURE [dbo].[ReWeightVehicleCardId_Delete]

GO

DROP PROCEDURE [dbo].[ReWeightVehicleCardId_InsertUpdate]

GO

DROP PROCEDURE [dbo].[ReWeightVehicleCardId_List]

GO

DROP PROCEDURE [dbo].[ReWighing_GetByCardId]

GO

DROP PROCEDURE [dbo].[ReWighing_GetByPlate]

GO

DROP PROCEDURE [dbo].[ReWighing_TV_GetByBascule]

GO

DROP FUNCTION [dbo].[CustomCalculation]

GO

