INSERT [dbo].[MasterTable] ([IdCompany], [IdTable], [IdColumn], [Valor], [Description], [IdFatherColumn], [IdStatus], [DeletedFlag], [CreatedIdCompany], [CreatedIdUser], [CreatedDate], [UpdatedIdCompany], [UpdatedIdUser], [UpdatedDate]) VALUES (1, 51, 0, N'', N'TV Estado Autorización', NULL, 1, 0, 1, 1, CAST(N'2023-12-12T11:00:00.000' AS DateTime), NULL, NULL, NULL)
GO
INSERT [dbo].[MasterTable] ([IdCompany], [IdTable], [IdColumn], [Valor], [Description], [IdFatherColumn], [IdStatus], [DeletedFlag], [CreatedIdCompany], [CreatedIdUser], [CreatedDate], [UpdatedIdCompany], [UpdatedIdUser], [UpdatedDate]) VALUES (1, 51, 1, N'', N'Autorización Pendiente - Imprimiendo Ticket', NULL, 1, 0, 1, 1, CAST(N'2023-12-12T11:00:00.000' AS DateTime), NULL, NULL, NULL)
GO
INSERT [dbo].[MasterTable] ([IdCompany], [IdTable], [IdColumn], [Valor], [Description], [IdFatherColumn], [IdStatus], [DeletedFlag], [CreatedIdCompany], [CreatedIdUser], [CreatedDate], [UpdatedIdCompany], [UpdatedIdUser], [UpdatedDate]) VALUES (1, 51, 2, N'', N'Autorizado', NULL, 1, 0, 1, 1, CAST(N'2023-12-12T11:00:00.000' AS DateTime), NULL, NULL, NULL)
GO
INSERT [dbo].[MasterTable] ([IdCompany], [IdTable], [IdColumn], [Valor], [Description], [IdFatherColumn], [IdStatus], [DeletedFlag], [CreatedIdCompany], [CreatedIdUser], [CreatedDate], [UpdatedIdCompany], [UpdatedIdUser], [UpdatedDate]) VALUES (1, 51, 3, N'', N'No Autorizado', NULL, 1, 0, 1, 1, CAST(N'2023-12-12T11:00:00.000' AS DateTime), NULL, NULL, NULL)
GO
INSERT [dbo].[MasterTable] ([IdCompany], [IdTable], [IdColumn], [Valor], [Description], [IdFatherColumn], [IdStatus], [DeletedFlag], [CreatedIdCompany], [CreatedIdUser], [CreatedDate], [UpdatedIdCompany], [UpdatedIdUser], [UpdatedDate]) VALUES (1, 51, 4, N'', N'Card Id No Asignado O Deshabilitado', NULL, 1, 0, 1, 1, CAST(N'2023-12-12T11:00:00.000' AS DateTime), NULL, NULL, NULL)
GO
INSERT [dbo].[MasterTable] ([IdCompany], [IdTable], [IdColumn], [Valor], [Description], [IdFatherColumn], [IdStatus], [DeletedFlag], [CreatedIdCompany], [CreatedIdUser], [CreatedDate], [UpdatedIdCompany], [UpdatedIdUser], [UpdatedDate]) VALUES (1, 51, 5, N'', N'Proceso Cerrado', NULL, 1, 0, 1, 1, CAST(N'2023-12-12T11:00:00.000' AS DateTime), NULL, NULL, NULL)
GO
INSERT [dbo].[MasterTable] ([IdCompany], [IdTable], [IdColumn], [Valor], [Description], [IdFatherColumn], [IdStatus], [DeletedFlag], [CreatedIdCompany], [CreatedIdUser], [CreatedDate], [UpdatedIdCompany], [UpdatedIdUser], [UpdatedDate]) VALUES (1, 51, 10, N'', N'Autorización Pendiente', NULL, 1, 0, 1, 1, CAST(N'2023-12-12T11:00:00.000' AS DateTime), NULL, NULL, NULL)
GO
INSERT [dbo].[MasterTable] ([IdCompany], [IdTable], [IdColumn], [Valor], [Description], [IdFatherColumn], [IdStatus], [DeletedFlag], [CreatedIdCompany], [CreatedIdUser], [CreatedDate], [UpdatedIdCompany], [UpdatedIdUser], [UpdatedDate]) VALUES (1, 52, 0, N'', N'TV Estado Peso', NULL, 1, 0, 1, 1, CAST(N'2023-12-12T11:00:00.000' AS DateTime), NULL, NULL, NULL)
GO
INSERT [dbo].[MasterTable] ([IdCompany], [IdTable], [IdColumn], [Valor], [Description], [IdFatherColumn], [IdStatus], [DeletedFlag], [CreatedIdCompany], [CreatedIdUser], [CreatedDate], [UpdatedIdCompany], [UpdatedIdUser], [UpdatedDate]) VALUES (1, 52, 1, N'', N'Esperando vehiculo', NULL, 1, 0, 1, 1, CAST(N'2023-12-12T11:00:00.000' AS DateTime), NULL, NULL, NULL)
GO
INSERT [dbo].[MasterTable] ([IdCompany], [IdTable], [IdColumn], [Valor], [Description], [IdFatherColumn], [IdStatus], [DeletedFlag], [CreatedIdCompany], [CreatedIdUser], [CreatedDate], [UpdatedIdCompany], [UpdatedIdUser], [UpdatedDate]) VALUES (1, 52, 2, N'', N'Peso Tara exitosa', NULL, 1, 0, 1, 1, CAST(N'2023-12-12T11:00:00.000' AS DateTime), NULL, NULL, NULL)
GO
INSERT [dbo].[MasterTable] ([IdCompany], [IdTable], [IdColumn], [Valor], [Description], [IdFatherColumn], [IdStatus], [DeletedFlag], [CreatedIdCompany], [CreatedIdUser], [CreatedDate], [UpdatedIdCompany], [UpdatedIdUser], [UpdatedDate]) VALUES (1, 52, 3, N'', N'Peso Bruto exitoso', NULL, 1, 0, 1, 1, CAST(N'2023-12-12T11:00:00.000' AS DateTime), NULL, NULL, NULL)
GO
INSERT [dbo].[MasterTable] ([IdCompany], [IdTable], [IdColumn], [Valor], [Description], [IdFatherColumn], [IdStatus], [DeletedFlag], [CreatedIdCompany], [CreatedIdUser], [CreatedDate], [UpdatedIdCompany], [UpdatedIdUser], [UpdatedDate]) VALUES (1, 52, 4, N'', N'Peso Bruto fuera de rango', NULL, 1, 0, 1, 1, CAST(N'2023-12-12T11:00:00.000' AS DateTime), NULL, NULL, NULL)
GO
INSERT [dbo].[MasterTable] ([IdCompany], [IdTable], [IdColumn], [Valor], [Description], [IdFatherColumn], [IdStatus], [DeletedFlag], [CreatedIdCompany], [CreatedIdUser], [CreatedDate], [UpdatedIdCompany], [UpdatedIdUser], [UpdatedDate]) VALUES (1, 52, 5, N'', N'Peso Tara fuera de rango', NULL, 1, 0, 1, 1, CAST(N'2023-12-12T11:00:00.000' AS DateTime), NULL, NULL, NULL)
GO
INSERT [dbo].[MasterTable] ([IdCompany], [IdTable], [IdColumn], [Valor], [Description], [IdFatherColumn], [IdStatus], [DeletedFlag], [CreatedIdCompany], [CreatedIdUser], [CreatedDate], [UpdatedIdCompany], [UpdatedIdUser], [UpdatedDate]) VALUES (1, 53, 0, N'', N'TV Estado Dirección', NULL, 1, 0, 1, 1, CAST(N'2023-12-12T11:00:00.000' AS DateTime), NULL, NULL, NULL)
GO
INSERT [dbo].[MasterTable] ([IdCompany], [IdTable], [IdColumn], [Valor], [Description], [IdFatherColumn], [IdStatus], [DeletedFlag], [CreatedIdCompany], [CreatedIdUser], [CreatedDate], [UpdatedIdCompany], [UpdatedIdUser], [UpdatedDate]) VALUES (1, 53, 1, N'', N'Esperando vehiculo', NULL, 1, 0, 1, 1, CAST(N'2023-12-12T11:00:00.000' AS DateTime), NULL, NULL, NULL)
GO
INSERT [dbo].[MasterTable] ([IdCompany], [IdTable], [IdColumn], [Valor], [Description], [IdFatherColumn], [IdStatus], [DeletedFlag], [CreatedIdCompany], [CreatedIdUser], [CreatedDate], [UpdatedIdCompany], [UpdatedIdUser], [UpdatedDate]) VALUES (1, 53, 2, N'', N'Dirección a zona de descarga', NULL, 1, 0, 1, 1, CAST(N'2023-12-12T11:00:00.000' AS DateTime), NULL, NULL, NULL)
GO
INSERT [dbo].[MasterTable] ([IdCompany], [IdTable], [IdColumn], [Valor], [Description], [IdFatherColumn], [IdStatus], [DeletedFlag], [CreatedIdCompany], [CreatedIdUser], [CreatedDate], [UpdatedIdCompany], [UpdatedIdUser], [UpdatedDate]) VALUES (1, 53, 3, N'', N'Dirección a zona de carga', NULL, 1, 0, 1, 1, CAST(N'2023-12-12T11:00:00.000' AS DateTime), NULL, NULL, NULL)
GO
INSERT [dbo].[MasterTable] ([IdCompany], [IdTable], [IdColumn], [Valor], [Description], [IdFatherColumn], [IdStatus], [DeletedFlag], [CreatedIdCompany], [CreatedIdUser], [CreatedDate], [UpdatedIdCompany], [UpdatedIdUser], [UpdatedDate]) VALUES (1, 53, 4, N'', N'Están cerca de alcanzar el peso para limpieza y destare', NULL, 1, 0, 1, 1, CAST(N'2023-12-12T11:00:00.000' AS DateTime), NULL, NULL, NULL)
GO
INSERT [dbo].[MasterTable] ([IdCompany], [IdTable], [IdColumn], [Valor], [Description], [IdFatherColumn], [IdStatus], [DeletedFlag], [CreatedIdCompany], [CreatedIdUser], [CreatedDate], [UpdatedIdCompany], [UpdatedIdUser], [UpdatedDate]) VALUES (1, 53, 5, N'', N'Deben ir a limpieza y obtención de peso tara', NULL, 1, 0, 1, 1, CAST(N'2023-12-12T11:00:00.000' AS DateTime), NULL, NULL, NULL)
GO
INSERT [dbo].[MasterTable] ([IdCompany], [IdTable], [IdColumn], [Valor], [Description], [IdFatherColumn], [IdStatus], [DeletedFlag], [CreatedIdCompany], [CreatedIdUser], [CreatedDate], [UpdatedIdCompany], [UpdatedIdUser], [UpdatedDate]) VALUES (1, 54, 0, N'', N'TV Estado Actual', NULL, 1, 0, 1, 1, CAST(N'2023-12-12T11:00:00.000' AS DateTime), NULL, NULL, NULL)
GO
INSERT [dbo].[MasterTable] ([IdCompany], [IdTable], [IdColumn], [Valor], [Description], [IdFatherColumn], [IdStatus], [DeletedFlag], [CreatedIdCompany], [CreatedIdUser], [CreatedDate], [UpdatedIdCompany], [UpdatedIdUser], [UpdatedDate]) VALUES (1, 54, 1, N'1', N'ID Estado Autorización', NULL, 1, 0, 1, 1, CAST(N'2023-12-12T11:00:00.000' AS DateTime), NULL, NULL, NULL)
GO
INSERT [dbo].[MasterTable] ([IdCompany], [IdTable], [IdColumn], [Valor], [Description], [IdFatherColumn], [IdStatus], [DeletedFlag], [CreatedIdCompany], [CreatedIdUser], [CreatedDate], [UpdatedIdCompany], [UpdatedIdUser], [UpdatedDate]) VALUES (1, 54, 2, N'1', N'ID Estado Peso', NULL, 1, 0, 1, 1, CAST(N'2023-12-12T11:00:00.000' AS DateTime), NULL, NULL, NULL)
GO
INSERT [dbo].[MasterTable] ([IdCompany], [IdTable], [IdColumn], [Valor], [Description], [IdFatherColumn], [IdStatus], [DeletedFlag], [CreatedIdCompany], [CreatedIdUser], [CreatedDate], [UpdatedIdCompany], [UpdatedIdUser], [UpdatedDate]) VALUES (1, 54, 3, N'1', N'ID Estado Dirección', NULL, 1, 0, 1, 1, CAST(N'2023-12-12T11:00:00.000' AS DateTime), NULL, NULL, NULL)
GO
INSERT [dbo].[MasterTable] ([IdCompany], [IdTable], [IdColumn], [Valor], [Description], [IdFatherColumn], [IdStatus], [DeletedFlag], [CreatedIdCompany], [CreatedIdUser], [CreatedDate], [UpdatedIdCompany], [UpdatedIdUser], [UpdatedDate]) VALUES (1, 1000, 0, N'', N'Parametros Generales', NULL, 1, 0, 1, 1, CAST(N'2023-12-12T11:00:00.000' AS DateTime), NULL, NULL, NULL)
GO
INSERT [dbo].[MasterTable] ([IdCompany], [IdTable], [IdColumn], [Valor], [Description], [IdFatherColumn], [IdStatus], [DeletedFlag], [CreatedIdCompany], [CreatedIdUser], [CreatedDate], [UpdatedIdCompany], [UpdatedIdUser], [UpdatedDate]) VALUES (1, 1000, 1, N'10', N'RWW - Tolerancia para registrar el valor', NULL, 1, 0, 1, 1, CAST(N'2023-12-12T11:00:00.000' AS DateTime), NULL, NULL, NULL)
GO
INSERT [dbo].[MasterTable] ([IdCompany], [IdTable], [IdColumn], [Valor], [Description], [IdFatherColumn], [IdStatus], [DeletedFlag], [CreatedIdCompany], [CreatedIdUser], [CreatedDate], [UpdatedIdCompany], [UpdatedIdUser], [UpdatedDate]) VALUES (1, 1000, 2, N'5', N'RWW - Tiempo limite sin que el valor varie para registrar (Segundos)', NULL, 1, 0, 1, 1, CAST(N'2023-12-12T11:00:00.000' AS DateTime), NULL, NULL, NULL)
GO
INSERT [dbo].[MasterTable] ([IdCompany], [IdTable], [IdColumn], [Valor], [Description], [IdFatherColumn], [IdStatus], [DeletedFlag], [CreatedIdCompany], [CreatedIdUser], [CreatedDate], [UpdatedIdCompany], [UpdatedIdUser], [UpdatedDate]) VALUES (1, 1000, 3, N'1000', N'RWW - Peso Minimo para un camión', NULL, 1, 0, 1, 1, CAST(N'2023-12-12T11:00:00.000' AS DateTime), NULL, NULL, NULL)
GO
INSERT [dbo].[MasterTable] ([IdCompany], [IdTable], [IdColumn], [Valor], [Description], [IdFatherColumn], [IdStatus], [DeletedFlag], [CreatedIdCompany], [CreatedIdUser], [CreatedDate], [UpdatedIdCompany], [UpdatedIdUser], [UpdatedDate]) VALUES (1, 1000, 4, N'5', N'TV - Tiempo permanece el mensaje al finalizar (Segundos)', NULL, 1, 0, 1, 1, CAST(N'2023-12-12T11:00:00.000' AS DateTime), NULL, NULL, NULL)
GO
INSERT [dbo].[MasterTable] ([IdCompany], [IdTable], [IdColumn], [Valor], [Description], [IdFatherColumn], [IdStatus], [DeletedFlag], [CreatedIdCompany], [CreatedIdUser], [CreatedDate], [UpdatedIdCompany], [UpdatedIdUser], [UpdatedDate]) VALUES (1, 1000, 5, N'1', N'RWW - Cantidad de copias al inprimir ticket entrada', NULL, 1, 0, 1, 1, CAST(N'2023-12-12T11:00:00.000' AS DateTime), NULL, NULL, NULL)
GO
INSERT [dbo].[MasterTable] ([IdCompany], [IdTable], [IdColumn], [Valor], [Description], [IdFatherColumn], [IdStatus], [DeletedFlag], [CreatedIdCompany], [CreatedIdUser], [CreatedDate], [UpdatedIdCompany], [UpdatedIdUser], [UpdatedDate]) VALUES (1, 1000, 6, N'1', N'RWW - Cantidad de copias al inprimir ticket salida', NULL, 1, 0, 1, 1, CAST(N'2023-12-12T11:00:00.000' AS DateTime), NULL, NULL, NULL)
GO
INSERT [dbo].[MasterTable] ([IdCompany], [IdTable], [IdColumn], [Valor], [Description], [IdFatherColumn], [IdStatus], [DeletedFlag], [CreatedIdCompany], [CreatedIdUser], [CreatedDate], [UpdatedIdCompany], [UpdatedIdUser], [UpdatedDate]) VALUES (1, 1000, 7, N'0', N'RWW  - Peso Actual', NULL, 1, 0, 1, 1, CAST(N'2023-12-12T11:00:00.000' AS DateTime), NULL, NULL, NULL)
GO
