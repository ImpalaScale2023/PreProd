CREATE TABLE [dbo].[CardId] (
    [IdCompany]        INT          NOT NULL,
    [IdCard]           INT          NOT NULL,
    [IdCompanyBranch]  INT          NOT NULL,
    [CodCard]          VARCHAR (30) NULL,
    [DescriptionCard]  VARCHAR (50) NULL,
    [IdStatus]         INT          NOT NULL,
    [DeletedFlag]      BIT          NOT NULL,
    [CreatedIdCompany] INT          NOT NULL,
    [CreatedIdUser]    INT          NOT NULL,
    [CreatedDate]      DATETIME     NOT NULL,
    [UpdatedIdCompany] INT          NULL,
    [UpdatedIdUser]    INT          NULL,
    [UpdatedDate]      DATETIME     NULL,
    [DeleteIdCompany]  INT          NULL,
    [DeleteIdUser]     INT          NULL,
    [DeleteDate]       DATETIME     NULL,
    CONSTRAINT [PK_CardId] PRIMARY KEY CLUSTERED ([IdCompany] ASC, [IdCard] ASC, [IdCompanyBranch] ASC)
);

GO

CREATE TABLE [dbo].[ReWeighing_Batch] (
    [IdReWeighing]   INT NOT NULL,
    [LimitBatchSize] INT NOT NULL
);

GO

CREATE TABLE [dbo].[ReWeightVehicleCardId] (
    [IdCompany]               INT      NOT NULL,
    [IdCompanyBranch]         INT      NOT NULL,
    [IdReWeightVehicleCardId] INT      NOT NULL,
    [IdReWeighing]            INT      NOT NULL,
    [IdVehicle]               INT      NOT NULL,
    [IdCardId]                INT      NOT NULL,
    [IdStatusWeigh]           INT      NOT NULL,
    [IdStatus]                INT      NOT NULL,
    [DeletedFlag]             BIT      NOT NULL,
    [CreatedIdCompany]        INT      NOT NULL,
    [CreatedIdUser]           INT      NOT NULL,
    [CreatedDate]             DATETIME NOT NULL,
    [UpdatedIdCompany]        INT      NULL,
    [UpdatedIdUser]           INT      NULL,
    [UpdatedDate]             DATETIME NULL,
    [DeleteIdCompany]         INT      NULL,
    [DeleteIdUser]            INT      NULL,
    [DeleteDate]              DATETIME NULL,
    [TareFlag]                BIT      NULL,
    CONSTRAINT [PK_ReWeightVehicleCardId] PRIMARY KEY CLUSTERED ([IdCompany] ASC, [IdCompanyBranch] ASC, [IdReWeightVehicleCardId] ASC),
    CONSTRAINT [FK_ReWeightVehicleCardId_ReWeighing] FOREIGN KEY ([IdCompany], [IdReWeighing]) REFERENCES [dbo].[ReWeighing] ([IdCompany], [IdReWeighing]),
    CONSTRAINT [FK_ReWeightVehicleCardId_ReWeightVehicleCardId] FOREIGN KEY ([IdCompany], [IdVehicle]) REFERENCES [dbo].[Vehicle] ([IdCompany], [IdVehicle])
);

GO

