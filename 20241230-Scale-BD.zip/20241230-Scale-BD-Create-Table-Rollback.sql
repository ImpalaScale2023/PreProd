DROP TABLE  [dbo].[CardId]

GO

DROP TABLE [dbo].[ReWeighing_Batch]

GO

DROP TABLE [dbo].[ReWeightVehicleCardId]