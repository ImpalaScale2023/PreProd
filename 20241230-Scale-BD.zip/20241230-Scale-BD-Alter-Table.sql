ALTER TABLE [dbo].[Bascule] 
ADD [FlagActiveCardReader] BIT,
[FlagCardReader] BIT

GO

ALTER TABLE [dbo].[ReWeighing]
ADD [MaxWeightTolerance] INT,
[BatchSize] INT,
[BatchSizeTolerance] INT,
[IdPrinter] INT,
[BatchSizeAcumulate] INT

GO

ALTER TABLE [dbo].[Vehicle]
ADD [TruckTareTolerance] INT,
[TruckMaxGrossWeight] INT,
[TrailerTareTolerance] INT