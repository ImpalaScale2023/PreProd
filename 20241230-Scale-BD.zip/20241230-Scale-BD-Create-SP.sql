CREATE PROCEDURE [dbo].[Bascule_Update_FlagCardReader]
@IdCompany INT,
@IdCompanyBranch INT,
@IdBascule INT,
@FlagCardReader BIT,
@IdType INT -- 1: Invocado desde el Sistema Web, 2: Windows Service
AS
BEGIN TRY

IF @IdType = 2
BEGIN
	UPDATE dbo.Bascule SET
	FlagCardReader = @FlagCardReader
	WHERE IdCompany = @IdCompany
	AND IdCompanyBranch = @IdCompanyBranch
	AND IdBascule = @IdBascule
END

SELECT 
0 AS Code,
ISNULL(FlagCardReader, 0) AS FlagCardReader,
'' AS [Message]
FROM dbo.Bascule 
WHERE IdCompany = @IdCompany
AND IdCompanyBranch = @IdCompanyBranch
AND IdBascule = @IdBascule

END TRY
BEGIN CATCH
    ROLLBACK TRAN
	SELECT 
	1 AS Code,
	CAST(0 AS BIT) AS FlagCardReader,
	CONCAT('L�nea N�', ERROR_LINE(), ': ', ERROR_MESSAGE()) AS [Message]
END CATCH

GO

CREATE PROCEDURE [dbo].[Card_InsertUpdate]
@IdCompany INT,
@IdCompanyBranch INT,
@IdCard INT,
@CodCard VARCHAR(30),
@DescriptionCard VARCHAR(50),
@IdStatus INT,
@IdUserAud INT,
@IdCompanyAud INT,
@Error varchar(MAX) OUTPUT
AS
BEGIN TRAN
BEGIN TRY
	IF @IdCard = 0
	BEGIN
		SELECT @IdCard = MAX(IdCard) FROM dbo.CardId WHERE IdCompany = @IdCompany AND IdCompanyBranch = @IdCompanyBranch
		INSERT INTO CardId(IdCompany, IdCard, IdCompanyBranch, CodCard, DescriptionCard, IdStatus, DeletedFlag, CreatedIdCompany,
							CreatedIdUser, CreatedDate)
		SELECT
		@IdCompany,
		ISNULL(@IdCard, 0) + 1,
		@IdCompanyBranch,
		@CodCard,
		@DescriptionCard,
		@IdStatus,
		0 AS DeleteFlag,
		@IdCompanyAud,
		@IdUserAud,
		dbo.FechaUTC(@IdCompany, @IdCompanyBranch)
	END
	ELSE IF @IdCard > 0
	BEGIN
		UPDATE CardId SET
		CodCard = @CodCard,
		IdStatus = @IdStatus,
		DescriptionCard = @DescriptionCard,
		UpdatedIdCompany = @IdCompanyAud,
		UpdatedIdUser = @IdUserAud
		WHERE IdCompany = @IdCompany
		AND IdCompanyBranch = @IdCompanyBranch
		AND IdCard = @IdCard
	END

	IF (SELECT COUNT(1) FROM CardId WHERE IdCompany = @IdCompany
		AND IdCompanyBranch = @IdCompanyBranch
		AND CodCard = @CodCard
		AND DeletedFlag = 0) > 1
	BEGIN
		ROLLBACK TRAN
		SET @Error = '#VALID!' + 'This register already exists'
	END
	ELSE
	BEGIN
		COMMIT TRAN
	END

END TRY
BEGIN CATCH
	ROLLBACK TRAN
	SET @Error = CONCAT('L�nea N�', ERROR_LINE(), ': ', ERROR_MESSAGE())
END CATCH

GO

--EXEC [dbo].[Card_List] 1, 1, 1, 1, '', 1, 10
CREATE PROCEDURE [dbo].[Card_List]
@IdCompany INT,
@IdCompanyBranch INT,
@TimeZone INT,
@IdStatus INT,
@Search VARCHAR(50),
@PageIndex INT,
@PageSize INT
AS
DECLARE @TotalElements INT

SELECT 
@TotalElements = COUNT(1) 
FROM dbo.CardId an
INNER JOIN MasterTable tblm ON tblm.IdTable = 1 AND tblm.IdColumn = an.IdStatus AND tblm.IdColumn > 0
INNER JOIN CompanyBranch cb ON cb.IdCompany = an.IdCompany AND cb.IdCompanyBranch = an.IdCompanyBranch
INNER JOIN Company com ON com.IdCompany = an.CreatedIdCompany
INNER JOIN [User] us1 ON us1.IdCompany = an.IdCompany AND us1.IdUser = an.CreatedIdUser
LEFT JOIN Company emp2 ON emp2.IdCompany = an.UpdatedIdCompany
LEFT JOIN [User] us2 ON us2.IdCompany = an.IdCompany AND us2.IdUser = an.UpdatedIdUser
WHERE an.IdCompany = @IdCompany 
AND (an.IdCompanyBranch = @IdCompanyBranch OR @IdCompanyBranch = 0)
AND an.DeletedFlag = 0
AND (@IdStatus = 0 OR an.IdStatus = @IdStatus)
AND (an.CodCard LIKE '%' + @Search + '%'
	OR cb.CodeCompanyBranch LIKE '%' + @Search + '%'
	OR @Search = ''
)


SELECT
an.IdCompany,
an.IdCard,
an.IdCompanyBranch,
an.CodCard,
ISNULL(an.DescriptionCard, '') AS DescriptionCard,
an.IdStatus,
tblm.[Description] AS [Status],
com.CompanyName AS CreatedCompany,
us1.UserLogin AS CreatedUser,
CONVERT(VARCHAR(10), an.CreatedDate, 120) + ' ' + CONVERT(VARCHAR(8), DATEADD(MINUTE, @TimeZone, an.CreatedDate), 108) AS CreatedDate,
ISNULL(emp2.CompanyName, ' ') AS UpdatedCompany,
ISNULL(us2.UserLogin, ' ') AS UpdatedUser,
ISNULL(CONVERT(VARCHAR(10), an.UpdatedDate, 120) + ' ' + CONVERT(VARCHAR(8), DATEADD(MINUTE, @TimeZone, an.UpdatedDate), 108), ' ') AS UpdatedDate,
@TotalElements AS TotalElements 
FROM dbo.CardId an
INNER JOIN MasterTable tblm ON tblm.IdTable = 1 AND tblm.IdColumn = an.IdStatus AND tblm.IdColumn > 0
INNER JOIN CompanyBranch cb ON cb.IdCompany = an.IdCompany AND cb.IdCompanyBranch = an.IdCompanyBranch
INNER JOIN Company com ON com.IdCompany = an.CreatedIdCompany
INNER JOIN [User] us1 ON us1.IdCompany = an.IdCompany AND us1.IdUser = an.CreatedIdUser
LEFT JOIN Company emp2 ON emp2.IdCompany = an.UpdatedIdCompany
LEFT JOIN [User] us2 ON us2.IdCompany = an.IdCompany AND us2.IdUser = an.UpdatedIdUser
WHERE an.IdCompany = @IdCompany 
AND (an.IdCompanyBranch = @IdCompanyBranch OR @IdCompanyBranch = 0)
AND an.DeletedFlag = 0
AND (@IdStatus = 0 OR an.IdStatus = @IdStatus)
AND (an.CodCard LIKE '%' + @Search + '%'
	OR cb.CodeCompanyBranch LIKE '%' + @Search + '%'
	OR @Search = ''
)
ORDER BY an.CodCard ASC
OFFSET @PageSize * (@PageIndex - 1) ROWS
FETCH NEXT @PageSize ROWS ONLY

GO

CREATE PROCEDURE [dbo].[CardId_Delete]
@IdCompany INT,
@IdCompanyBranch INT,
@IdCard INT,
@IdUserAud INT,
@IdCompanyAud VARCHAR(50),
@Error varchar(MAX) OUTPUT
AS
BEGIN TRY
	SET @Error = ''
	UPDATE dbo.CardId SET
	DeletedFlag = 1,
	DeleteIdUser = @IdUserAud,
	CreatedDate = dbo.FechaUTC(@IdCompany, @IdCompanyBranch),
	DeleteIdCompany = @IdCompanyAud
	WHERE IdCompany = @IdCompany
	AND IdCompanyBranch = @IdCompanyBranch
	AND IdCard = @IdCard
	
END TRY
BEGIN CATCH
	SET @Error = CONCAT('L�nea N�', ERROR_LINE(), ': ', ERROR_MESSAGE())
END CATCH

GO

--EXEC [dbo].[ReWeghingWeight_Cancel] 1, 1, ''
CREATE PROCEDURE [dbo].[ReWeghingWeight_Cancel]
@IdCompany INT,
@IdCompanyBranch INT,
@Error VARCHAR(MAX) OUTPUT
AS
BEGIN TRY  
	UPDATE dbo.ReWeightVehicleCardId
	SET IdStatusWeigh = 1
	WHERE IdCompany = @IdCompany
	AND IdCompanyBranch = @IdCompanyBranch
	AND DeletedFlag = 0
    
	UPDATE dbo.MasterTable
	SET Valor =
		CASE IdColumn
			WHEN 1 THEN 10
			WHEN 2 THEN 1
			--WHEN 3 THEN 1
			ELSE Valor
		END
	WHERE IdTable = 54
	AND IdColumn IN (1, 2);
	--COMMIT TRAN  
END TRY  
BEGIN CATCH  
    --ROLLBACK TRAN  
    SET @Error = CONCAT('L�nea N�', ERROR_LINE(), ': ', ERROR_MESSAGE())  
END CATCH

GO

-- [dbo].[ReWeighingWeight_ReportTruck] 1, 1, 300, '20220214', '20240214'
CREATE PROCEDURE [dbo].[ReWeighingWeight_ReportTruck_ V2]
@IdCompany INT,
@IdCompanyBranch INT,
@TimeZone INT,
@InitialDate VARCHAR(8),
@FinalDate VARCHAR(8)
AS
SELECT
rw.Pila,
rww.Lot,
CONCAT(ve.TruckNumber, '/', ve.TrailerNumber) AS Plate,
ISNULL(ca.Carrier, '') AS Carrier,
ISNULL(rww.[Sequence], 0) AS [Sequence],
CONCAT(rw.LotFrom, ' - ', rw.LotTo) AS LoteReWeight,
rww.GrossWeight,
rww.TareWeight,
rww.NetWeight,
ISNULL(CONVERT(VARCHAR(10), rww.GrossDate, 120) + ' ' + CONVERT(VARCHAR(8), DATEADD(MINUTE, @TimeZone, rww.GrossDate), 108),'') AS GrossDate,
ISNULL(CONVERT(VARCHAR(10), rww.GrossDate, 120),'') AS GrossDateOnly,
ISNULL(CONVERT(VARCHAR(8), DATEADD(MINUTE, @TimeZone, rww.GrossDate), 108),'') AS GrossHour,
pr.DescProduct,
qu.[Description] AS Quality,
cl.BusinessName AS Client,
--CONVERT(VARCHAR(10), rww.TareDate, 120) + ' ' + CONVERT(VARCHAR(8), DATEADD(MINUTE, @TimeZone, rww.TareDate), 108) AS TareDate,
--DATEDIFF(MINUTE, rww.TareDate, rww.GrossDate) AS TimeDiff,
rww.Obs
FROM ReWeighingWeight rww
INNER JOIN Vehicle ve ON ve.IdCompany = rww.IdCompany AND ve.IdCompanyBranch = rww.IdCompanyBranch AND ve.IdVehicle = rww.IdVehicle
LEFT JOIN Carrier ca ON ca.IdCompany = ve.IdCompany AND ca.IdCompanyBranch = ve.IdCompanyBranch AND ca.IdCarrier = ve.IdCarrier
INNER JOIN ReWeighing rw ON rw.IdCompany = rww.IdCompany AND rw.IdCompanyBranch = rww.IdCompanyBranch 
						AND rw.IdReWeighing = rww.IdReWeighing AND rw.DeletedFlag = 0
INNER JOIN Product pr ON pr.IdCompany = rw.IdCompany AND pr.IdCompanyBranch = rw.IdCompanyBranch AND pr.IdProduct = rw.IdProduct
INNER JOIN Quality qu ON qu.IdCompany = rw.IdCompany AND qu.IdCompanyBranch = rw.IdCompanyBranch AND qu.IdQuality = rw.IdQuality
INNER JOIN Client cl ON cl.IdCompany = rw.IdCompany AND cl.IdCompanyBranch = rw.IdCompanyBranch AND cl.IdClient = rw.IdClient
WHERE rww.IdCompany = @IdCompany
AND rww.IdCompanyBranch = @IdCompanyBranch
AND CONVERT(date, rww.CreatedDate) BETWEEN CONVERT(date, @InitialDate) AND CONVERT(date, @FinalDate)
AND rww.DeletedFlag = 0
ORDER BY rw.IdReWeighing ASC

GO

CREATE PROCEDURE [dbo].[ReWeightVehicleCardId_Delete]
@IdCompany INT,
@IdCompanyBranch INT,
@IdReWeightVehicleCardId INT,
@IdUserAud INT,
@IdCompanyAud INT,
@Error varchar(MAX) OUTPUT
AS
BEGIN TRAN
BEGIN TRY
	SET @Error = ''
	UPDATE [dbo].[ReWeightVehicleCardId] SET
	DeletedFlag = 1,
	UpdatedIdUser = @IdUserAud,
	UpdatedDate = GETUTCDATE(),
	UpdatedIdCompany = @IdCompanyAud
	WHERE IdCompany = @IdCompany
	AND IdCompanyBranch = @IdCompanyBranch
	AND IdReWeightVehicleCardId = @IdReWeightVehicleCardId

	COMMIT TRAN
END TRY
BEGIN CATCH
	ROLLBACK TRAN
	SET @Error = CONCAT('L�nea N�', ERROR_LINE(), ': ', ERROR_MESSAGE())
END CATCH

GO

CREATE PROCEDURE [dbo].[ReWeightVehicleCardId_InsertUpdate]
@IdCompany INT,
@IdCompanyBranch INT,
@IdReWeightVehicleCardId INT,
@IdReWeighing INT,
@IdVehicle INT,
@IdCard INT,
@FlagReasignar BIT,
@IdStatus INT,
@IdUserAud INT,
@IdCompanyAud INT,
@Error varchar(MAX) OUTPUT
AS
BEGIN TRAN
BEGIN TRY
	IF @IdReWeightVehicleCardId = 0
	BEGIN
		SELECT 
		@IdReWeightVehicleCardId = ISNULL(MAX(IdReWeightVehicleCardId), 0) + 1 
		FROM dbo.ReWeightVehicleCardId WHERE IdCompany = @IdCompany AND IdCompanyBranch = @IdCompanyBranch

		INSERT INTO dbo.ReWeightVehicleCardId(IdCompany, IdCompanyBranch, IdReWeightVehicleCardId, IdReWeighing, 
						IdVehicle, IdCardId, IdStatus, IdStatusWeigh, DeletedFlag, CreatedIdCompany,
							CreatedIdUser, CreatedDate, TareFlag)
		SELECT
		@IdCompany,
		@IdCompanyBranch,
		@IdReWeightVehicleCardId,
		@IdReWeighing,
		@IdVehicle,
		@IdCard,
		@IdStatus,
		1,
		0 AS DeleteFlag,
		@IdCompanyAud,
		@IdUserAud,
		dbo.FechaUTC(@IdCompany, @IdCompanyBranch),
		1
	END
	ELSE IF @IdReWeightVehicleCardId > 0
	BEGIN
		UPDATE ReWeightVehicleCardId SET
		IdReWeighing = @IdReWeighing,
		IdVehicle = @IdVehicle,
		IdCardId = @IdCard,
		UpdatedIdCompany= @IdCompanyAud,
		UpdatedIdUser = @IdUserAud
		WHERE IdCompany = @IdCompany
		AND IdCompanyBranch = @IdCompanyBranch
		AND IdReWeightVehicleCardId = @IdReWeightVehicleCardId
	END

	IF(@FlagReasignar = 1)
	BEGIN
	
	UPDATE ReWeightVehicleCardId SET
	IdCardId = @IdCard,
	UpdatedIdCompany= @IdCompanyAud,
	UpdatedIdUser = @IdUserAud
	WHERE IdCompany = @IdCompany
	AND IdCompanyBranch = @IdCompanyBranch
	AND IdReWeightVehicleCardId = @IdReWeightVehicleCardId
	
	UPDATE ReWeightVehicleCardId SET
	DeletedFlag = 1,
	UpdatedIdCompany= @IdCompanyAud,
	UpdatedIdUser = @IdUserAud
	WHERE IdCompany = @IdCompany
	AND IdCompanyBranch = @IdCompanyBranch
	AND IdReWeightVehicleCardId <> @IdReWeightVehicleCardId
	AND IdCardId = @IdCard

	END

	IF (SELECT COUNT(1) 
		FROM ReWeightVehicleCardId car
		INNER JOIN ReWeighing re ON re.IdCompany = car.IdCompany 
									AND re.IdCompanyBranch = car.IdCompanyBranch 
									AND re.IdReWeighing = car.IdReWeighing 
									AND re.IdStatus < 3
		WHERE car.IdCompany = @IdCompany
		AND car.IdCompanyBranch = @IdCompanyBranch
		--AND IdReWeighing = @IdReWeighing
		--AND IdVehicle = @IdVehicle
		AND car.IdCardId = @IdCard
		AND car.DeletedFlag = 0) > 1
	BEGIN
		ROLLBACK TRAN
		SET @Error = '#CONFIRM!' + 'Este CardID ya esta asignado a otro vehiculo. Deseas Re-asignar el Card-ID?'
	END
	ELSE IF (SELECT COUNT(1) FROM ReWeightVehicleCardId car
		INNER JOIN ReWeighing re ON re.IdCompany = car.IdCompany 
									AND re.IdCompanyBranch = car.IdCompanyBranch 
									AND re.IdReWeighing = car.IdReWeighing 
									AND re.IdStatus < 3
		WHERE car.IdCompany = @IdCompany
		AND car.IdCompanyBranch = @IdCompanyBranch
		AND re.IdReWeighing = @IdReWeighing
		AND car.IdVehicle = @IdVehicle
		AND car.DeletedFlag = 0) > 1
	BEGIN
		ROLLBACK TRAN
		SET @Error = '#VALID!' + 'Este veh�culo ya esta registrado en este lote'
	END
	ELSE
	BEGIN
		COMMIT TRAN
	END

END TRY
BEGIN CATCH
	ROLLBACK TRAN
	SET @Error = CONCAT('L�nea N�', ERROR_LINE(), ': ', ERROR_MESSAGE())
END CATCH

GO

CREATE PROCEDURE [dbo].[ReWeightVehicleCardId_List]
@IdCompany INT,
@IdCompanyBranch INT,
@IdReWeighing INT,
@TimeZone INT,
@IdStatus INT,
@Search VARCHAR(50),
@PageIndex INT,
@PageSize INT
AS
DECLARE @TotalElements INT
SELECT @TotalElements = COUNT(1) 
FROM dbo.ReWeightVehicleCardId an
INNER JOIN dbo.Vehicle ve ON an.IdCompany = ve.IdCompany AND ve.IdVehicle = an.IdVehicle
INNER JOIN dbo.CardId ca ON an.IdCompany = ca.IdCompany AND an.IdCompanyBranch = ca.IdCompanyBranch AND ca.IdCard = an.IdCardId AND ca.DeletedFlag = 0
INNER JOIN MasterTable tblm ON an.IdCompany = tblm.IdCompany AND tblm.IdTable = 1 AND tblm.IdColumn = an.IdStatus AND tblm.IdColumn > 0
INNER JOIN CompanyBranch cb ON cb.IdCompany = an.IdCompany AND cb.IdCompanyBranch = an.IdCompanyBranch
INNER JOIN Company com ON com.IdCompany = an.CreatedIdCompany
INNER JOIN [User] us1 ON us1.IdCompany = an.IdCompany AND us1.IdUser = an.CreatedIdUser
LEFT JOIN Company emp2 ON emp2.IdCompany = an.UpdatedIdCompany
LEFT JOIN [User] us2 ON us2.IdCompany = an.IdCompany AND us2.IdUser = an.UpdatedIdUser
WHERE an.IdCompany = @IdCompany 
AND (an.IdCompanyBranch = @IdCompanyBranch OR @IdCompanyBranch = 0)
AND an.DeletedFlag = 0
AND an.IdStatus = @IdStatus
AND an.IdReWeighing = @IdReWeighing
AND (ve.TruckNumber LIKE '%' + @Search + '%'
	OR ve.TrailerNumber LIKE '%' + @Search + '%'
	OR ca.CodCard LIKE '%' + @Search + '%'
	OR ca.DescriptionCard LIKE '%' + @Search + '%'
	OR @Search = ''
)

SELECT
an.IdCompany,
an.IdCompanyBranch,
an.IdReWeightVehicleCardId,
an.IdReWeighing,
an.IdVehicle,
ve.TruckNumber,
ve.TrailerNumber,
an.IdCardId,
ca.DescriptionCard AS CodCard,
tblm.IdColumn AS IdStatus,
tblm.[Description] AS [Status],
com.CompanyName AS CreatedCompany,
us1.UserLogin AS CreatedUser,
CONVERT(VARCHAR(10), an.CreatedDate, 120) + ' ' + CONVERT(VARCHAR(8), DATEADD(MINUTE, @TimeZone, an.CreatedDate), 108) AS CreatedDate,
ISNULL(emp2.CompanyName, ' ') AS UpdatedCompany,
ISNULL(us2.UserLogin, ' ') AS UpdatedUser,
ISNULL(CONVERT(VARCHAR(10), an.UpdatedDate, 120) + ' ' + CONVERT(VARCHAR(8), DATEADD(MINUTE, @TimeZone, an.UpdatedDate), 108), ' ') AS UpdatedDate,
@TotalElements AS TotalElements 
FROM dbo.ReWeightVehicleCardId an
INNER JOIN dbo.Vehicle ve ON an.IdCompany = ve.IdCompany AND ve.IdVehicle = an.IdVehicle
INNER JOIN dbo.CardId ca ON an.IdCompany = ca.IdCompany AND an.IdCompanyBranch = ca.IdCompanyBranch AND ca.IdCard = an.IdCardId AND ca.DeletedFlag = 0
INNER JOIN MasterTable tblm ON an.IdCompany = tblm.IdCompany AND tblm.IdTable = 1 AND tblm.IdColumn = IIF(ve.DeletedFlag = 1, 2, ca.IdStatus) AND tblm.IdColumn > 0
INNER JOIN CompanyBranch cb ON cb.IdCompany = an.IdCompany AND cb.IdCompanyBranch = an.IdCompanyBranch
INNER JOIN Company com ON com.IdCompany = an.CreatedIdCompany
INNER JOIN [User] us1 ON us1.IdCompany = an.IdCompany AND us1.IdUser = an.CreatedIdUser
LEFT JOIN Company emp2 ON emp2.IdCompany = an.UpdatedIdCompany
LEFT JOIN [User] us2 ON us2.IdCompany = an.IdCompany AND us2.IdUser = an.UpdatedIdUser
WHERE an.IdCompany = @IdCompany 
AND (an.IdCompanyBranch = @IdCompanyBranch OR @IdCompanyBranch = 0)
AND an.DeletedFlag = 0
AND an.IdStatus = @IdStatus
AND an.IdReWeighing = @IdReWeighing
AND (ve.TruckNumber LIKE '%' + @Search + '%'
	OR ve.TrailerNumber LIKE '%' + @Search + '%'
	OR ca.CodCard LIKE '%' + @Search + '%'
	OR ca.DescriptionCard LIKE '%' + @Search + '%'
	OR @Search = ''
)
ORDER BY IdReWeightVehicleCardId ASC
OFFSET @PageSize * (@PageIndex - 1) ROWS
FETCH NEXT @PageSize ROWS ONLY

GO

--EXEC [dbo].[ReWighing_GetByCardId] 1, 1, 'T_0002sad'
CREATE PROCEDURE [dbo].[ReWighing_GetByCardId]
@IdCompany INT,
@IdCompanyBranch INT,
@CodCardId VARCHAR(30)
AS
BEGIN TRAN
BEGIN TRY
DECLARE @Id INT = 0
DECLARE @Message VARCHAR(200) = ''
DECLARE @IdStatus BIT = 1

IF (SELECT COUNT(1) FROM dbo.ReWeightVehicleCardId WHERE IdCompany = @IdCompany AND IdCompanyBranch = @IdCompanyBranch AND DeletedFlag = 0 AND IdStatusWeigh = 2) = 0
BEGIN
	SELECT 
	@Id = rwcc.IdReWeightVehicleCardId 
	FROM dbo.ReWeightVehicleCardId rwcc
	INNER JOIN dbo.CardId ca ON rwcc.IdCardId = ca.IdCard
											AND ca.IdCompany = rwcc.IdCompany 
											AND ca.IdCompanyBranch = rwcc.IdCompanyBranch
											AND ca.DeletedFlag = 0
	INNER JOIN	dbo.Vehicle ve ON ve.IdCompany = rwcc.IdCompany AND ve.IdCompanyBranch = rwcc.IdCompanyBranch AND ve.IdVehicle = rwcc.IdVehicle AND ve.DeletedFlag = 0
	WHERE rwcc.IdCompany = @IdCompany
	AND rwcc.IdCompanyBranch = @IdCompanyBranch
	AND ca.CodCard = @CodCardId
	AND rwcc.DeletedFlag = 0
	AND rwcc.IdStatusWeigh = 1
	--SELECT @Id
	IF @Id > 0
	BEGIN
		UPDATE dbo.ReWeightVehicleCardId
		SET IdStatusWeigh = 2
		WHERE IdReWeightVehicleCardId = @Id

		UPDATE dbo.ReWeightVehicleCardId
		SET IdStatusWeigh = 1
		WHERE IdReWeightVehicleCardId <> @Id
			
		UPDATE dbo.MasterTable
		SET Valor =
			CASE IdColumn
				WHEN 1 THEN 2
				WHEN 2 THEN 5
				--WHEN 3 THEN 2
				--ELSE Valor
			END
		WHERE IdTable = 54
		AND IdColumn IN (1, 2)
	
	END
	ELSE
	BEGIN
		UPDATE dbo.ReWeightVehicleCardId
		SET IdStatusWeigh = 1

		UPDATE dbo.MasterTable
		SET Valor =
			CASE IdColumn
				WHEN 1 THEN 4
				WHEN 2 THEN 1
				--WHEN 3 THEN 1
				--ELSE Valor
			END
		WHERE IdTable = 54
		AND IdColumn IN (1, 2);

		SET @IdStatus = 0
		SET @Message = 'Card ID no encontrado'
	END
END
ELSE
BEGIN
	SET @Message = 'Ya hay un proceso'
END
	COMMIT TRAN
	SELECT @IdStatus AS Ok, @Message AS [Message]
END TRY
BEGIN CATCH
	ROLLBACK TRAN
	SELECT
	CAST(0 AS BIT) AS Tipo, 
	CONCAT('L�nea de Error #', CAST(ERROR_LINE() AS VARCHAR(4)), ': ' + ERROR_MESSAGE()) AS [Message]
END CATCH

GO

--EXEC [dbo].[ReWighing_GetByPlate] 1, 1, 'V6H-942', 'V6H-942'
CREATE PROCEDURE [dbo].[ReWighing_GetByPlate]
@IdCompany INT,
@IdCompanyBranch INT,
@TruckNumber VARCHAR(20),
@TrailerNumber VARCHAR(20)
AS
BEGIN
DECLARE @Id INT = 0
SELECT @Id = rwcc.IdReWeightVehicleCardId FROM dbo.ReWeightVehicleCardId rwcc
			INNER JOIN dbo.Vehicle ve ON rwcc.IdVehicle = ve.IdVehicle 
										AND ve.IdCompany = rwcc.IdCompany 
										AND ve.IdCompanyBranch = rwcc.IdCompanyBranch
										AND ve.DeletedFlag = 0
			WHERE rwcc.IdCompany = @IdCompany
			AND rwcc.IdCompanyBranch = @IdCompanyBranch
			AND ve.TruckNumber = @TruckNumber
			AND ve.TrailerNumber = @TrailerNumber
			AND rwcc.DeletedFlag = 0

IF @Id > 0
BEGIN
	SELECT CAST(1 AS BIT) AS Ok, '' AS [Message]

	UPDATE dbo.ReWeightVehicleCardId
	SET IdStatus = 2
	WHERE IdReWeightVehicleCardId = @Id

	UPDATE dbo.ReWeightVehicleCardId
	SET IdStatus = 1
	WHERE IdReWeightVehicleCardId <> @Id
			
END
ELSE
BEGIN
	SELECT CAST(0 AS BIT) AS Ok, 'Placa no encontrada' AS [Message]
END
END

GO

-- [dbo].[ReWighing_TV_GetByBascule] 1, 1, 0, 3
CREATE PROCEDURE [dbo].[ReWighing_TV_GetByBascule]
@IdCompany INT,
@IdCompanyBranch INT,
@TimeZone INT,
@IdBascule INT
AS
DECLARE @Weight INT, 
@IdStatusRWW INT,  
@FlagLeer BIT,
@IdEstadoAutorizado INT,
@IdCapturaPeso INT,
@IdDireccion INT,
@WeightMinTare INT,
@CurrentLot INT,
@CurrentWeightLot INT

SELECT 
    @IdEstadoAutorizado = 
        CASE IdColumn
            WHEN 1 THEN Valor
            ELSE @IdEstadoAutorizado
        END,
    @IdCapturaPeso = 
        CASE IdColumn
            WHEN 2 THEN Valor
            ELSE 1
        END,
    @IdDireccion = 
        CASE IdColumn
            WHEN 3 THEN Valor
        END
FROM dbo.MasterTable
WHERE IdTable = 54
AND IdColumn IN (1, 2, 3);

SELECT @WeightMinTare = CONVERT(INT, Valor) FROM  dbo.MasterTable WHERE IdTable = 1000 AND IdColumn = 3

SELECT 
@Weight = Peso,
@FlagLeer = FlagLeer
FROM dbo.Bascule WHERE IdCompany = @IdCompany AND IdCompanyBranch = @IdCompanyBranch AND IdBascule = @IdBascule

SELECT
@IdEstadoAutorizado AS IdEstadoAutorizado,
@IdCapturaPeso AS IdCapturaPeso,
@IdDireccion AS IdDireccion,
rw.IdReWeighing,
rww.IdReWeighingWeight,
car.CodCard AS CardId,
rw.Pila AS Pila,
ve.IdVehicle,
ve.TruckNumber AS TruckPlate,
pr.DescProduct AS Product,
ve.TrailerNumber AS TrailerPlate,
qu.[Description] AS Quality,
rw.[Weight] AS InstructedWeight,
rw.ReWeight AS ReWeight,
rw.[Weight] - rw.ReWeight AS ToReWeigh,
rw.MaxWeighing AS Lotization,
rw.ReWeight AS Advance,
rw.LotTo AS LotToClose,
--rww.Lot AS LotToClose,
rw.MaxWeighing AS LotSize,
0 AS DesTare,
rwvc.IdStatusWeigh,
(ISNULL(ve.TruckTare, 0) + ISNULL(ve.TrailerTare, 0) - ISNULL(TruckTareTolerance, 0)) AS TareWeightMin,
(ISNULL(ve.TruckTare, 0) + ISNULL(ve.TrailerTare, 0) + ISNULL(TruckTareTolerance, 0)) AS GrossWeightMin,
IIF(ISNULL(rww.TareWeight, 0) = 0, 0, @Weight) AS GrossWeight,
IIF(ISNULL(rww.TareWeight, 0) = 0, @Weight, rww.TareWeight) AS TareWeight,
IIF(rww.TareWeight = 0, 0, @Weight - rww.TareWeight) AS NetWeight,
car.IdStatus, 
rw.IdStatus AS IdStatusRW,
rw.[BatchSize],
rw.BatchSizeTolerance,
(SELECT LimitBatchSize FROM dbo.ReWeighing_Batch rwb WHERE rwb.IdReWeighing = rw.IdReWeighing) AS BatchSizeAcumulate,
ISNULL(rwvc.TareFlag, 1) AS TareFlag
INTO #data
FROM dbo.ReWeightVehicleCardId rwvc
INNER JOIN dbo.CardId car ON car.IdCompany = rwvc.IdCompany AND car.IdCompanyBranch = rwvc.IdCompanyBranch AND car.IdCard = rwvc.IdCardId
INNER JOIN dbo.ReWeighing rw ON rwvc.IdReWeighing = rw.IdReWeighing AND rw.IdStatus IN (1, 2, 3)
INNER JOIN dbo.Product pr ON rw.IdProduct = pr.IdProduct
INNER JOIN dbo.Quality qu ON rw.IdQuality = qu.IdQuality
INNER JOIN dbo.Vehicle ve ON rwvc.IdVehicle = ve.IdVehicle 
							AND ve.IdCompany = rwvc.IdCompany 
							AND ve.IdCompanyBranch = rwvc.IdCompanyBranch
							AND ve.DeletedFlag = 0
LEFT JOIN dbo.ReWeighingWeight rww ON rww.IdVehicle = ve.IdVehicle AND rww.IdStatusWeight < 2 AND rww.DeletedFlag = 0 AND rww.IdReWeighing = rw.IdReWeighing
--LEFT JOIN dbo.ReWeighingWeight rww ON rww.IdVehicle = ve.IdVehicle AND rww.DeletedFlag = 0 AND rww.IdReWeighing = rw.IdReWeighing
WHERE rwvc.IdCompany = @IdCompany
AND rwvc.IdCompanyBranch = @IdCompanyBranch
AND rwvc.DeletedFlag = 0
AND rwvc.IdStatusWeigh = 2
--AND @FlagLeer = 1

IF (SELECT COUNT(1) FROM #data) > 0
BEGIN
	DECLARE @IdStatus INT, @IdStatusRW INT;
	SELECT @IdStatus = IdStatus, @IdStatusRW = IdStatusRW FROM #data
	IF @IdStatus = 1 AND @IdStatusRW < 3
	BEGIN
		DECLARE @TareWeight INT, @CantRow INT

		-- Validar bien esa parte
		SELECT TOP(1) 
		@TareWeight = IIF(rewe.GrossWeight > 0, rewe.TareWeight, 0),
		@CantRow = rewe.IdCompany
		FROM ReWeighingWeight rewe
		INNER JOIN #data tmp ON tmp.IdReWeighing = rewe.IdReWeighing AND tmp.IdVehicle = rewe.IdVehicle
		where rewe.IdCompany = @IdCompany
		AND rewe.DeletedFlag = 0
		order by rewe.IdReWeighingWeight desc

		SET @TareWeight = ISNULL(@TareWeight, 0)
		SET @CantRow = ISNULL(@CantRow, 0)
		--SET @TareWeight = ISNULL((select top 1 rewe.TareWeight from ReWeighingWeight rewe
		--													INNER JOIN #data tmp ON tmp.IdReWeighing = rewe.IdReWeighing AND tmp.IdVehicle = rewe.IdVehicle
		--						where rewe.IdCompany = @IdCompany
		--						AND rewe.DeletedFlag = 0
		--						AND rewe.GrossWeight > 0
		--						order by rewe.IdReWeighingWeight desc),0) 
		--SELECT @TareWeight
		SELECT @CurrentLot = ISNULL(MAX(rewe.Lot), 1), @CurrentWeightLot = ISNULL(SUM(rewe.NetWeight), 0)
		FROM dbo.ReWeighingWeight rewe
		INNER JOIN #data tmp ON tmp.IdReWeighing = rewe.IdReWeighing
		WHERE rewe.IdCompany = @IdCompany
		AND rewe.DeletedFlag = 0
		--ORDER BY rewe.IdReWeighingWeight desc
		GROUP BY rewe.Lot

		SELECT 
		@IdCapturaPeso = IIF(@TareWeight > 0, 
						IIF(TareFlag = 0, IIF(@Weight > GrossWeightMin, 3, 4), IIF(TareWeight <= IIF(TareWeightMin > @WeightMinTare, TareWeightMin, @WeightMinTare) OR TareWeight >= GrossWeightMin, 5, 2)),
						IIF(ISNULL(@CantRow, 0) > 0, IIF(@Weight > GrossWeightMin, 3, 4), IIF(TareWeight <= IIF(TareWeightMin > @WeightMinTare, TareWeightMin, @WeightMinTare) OR TareWeight >= GrossWeightMin, 5, 2))
						),
		@IdDireccion = IIF(GrossWeight = 0, 3, 2) -- 4, 5
		FROM #data

		--SELECT @TareWeight, ISNULL(GrossWeight, 0),  TareWeight, GrossWeightMin FROM #data
		--SELECT * FROM MasterTable WHERE IdTable = 53
		--SET @IdEstadoAutorizado = 2
		UPDATE dbo.MasterTable 
		SET Valor = @IdCapturaPeso
		WHERE IdTable = 54 
		AND IdColumn = 2

		--SELECT *, @TareWeight, @CantRow AS CantRow FROM #data
		
		SELECT
		TOP(1)
		ISNULL(da.IdReWeighingWeight, 0) AS IdReWeighingWeight,
		@IdEstadoAutorizado AS IdEstadoAutorizado,
		(SELECT [Description] FROM dbo.MasterTable WHERE IdTable = 51 AND IdColumn = @IdEstadoAutorizado) AS EstadoAutorizado,
		@IdCapturaPeso AS IdCapturaPeso,
		(SELECT [Description] FROM dbo.MasterTable WHERE IdTable = 52 AND IdColumn = @IdCapturaPeso) AS CapturaPeso,
		@IdDireccion AS IdDireccion,
		(SELECT [Description] FROM dbo.MasterTable WHERE IdTable = 53 AND IdColumn = @IdDireccion) AS Direccion,
		da.IdReWeighing,
		da.CardId,
		da.Pila,
		IIF(@IdCapturaPeso IN (2, 5), ISNULL(da.TareWeight, 0), IIF(@TareWeight > 0, @TareWeight, da.TareWeight)) AS TareWeight,
		da.IdVehicle,
		da.TruckPlate,
		da.Product,
		IIF(@IdCapturaPeso IN (3, 4), @Weight, 0) AS GrossWeight,
		--ISNULL(da.GrossWeight, 0) AS GrossWeight,
		da.TrailerPlate,
		da.Quality,
		--ISNULL(da.GrossWeight, 0) - ISNULL(da.TareWeight, 0) AS NetWeight,
		IIF(@IdCapturaPeso IN (3, 4), @Weight - IIF(@TareWeight > 0, @TareWeight, da.TareWeight), 0) AS NetWeight,
		da.InstructedWeight,
		da.ReWeight,
		da.ToReWeigh,
		da.Lotization,
		--(da.Advance + IIF(@TareWeight = 0, 0, @Weight - @TareWeight)) AS Advance,
		ISNULL(@CurrentWeightLot, 0) AS Advance,
		ISNULL(@CurrentLot, 1) AS LotToClose,
		da.LotSize,
		([BatchSize] - dbo.CustomCalculation([BatchSize], Advance)) AS DesTare,
		ISNULL(da.TareWeightMin, 0) AS TareWeightMin,
		ISNULL(da.GrossWeightMin, 0) AS GrossWeightMin,
		[BatchSize],
		BatchSizeTolerance,
		dbo.CustomCalculation([BatchSize], Advance) AS BatchSizeAcumulate,
		TareFlag
		FROM #data da
	END
	ELSE
	BEGIN
		SET @IdEstadoAutorizado = IIF(@IdStatusRW = 3, 5, 4)
		SELECT
		@IdEstadoAutorizado AS IdEstadoAutorizado,
		(SELECT [Description] FROM dbo.MasterTable WHERE IdTable = 51 AND IdColumn = @IdEstadoAutorizado) AS EstadoAutorizado,
		@IdCapturaPeso AS IdCapturaPeso,
		(SELECT [Description] FROM dbo.MasterTable WHERE IdTable = 52 AND IdColumn = @IdCapturaPeso) AS CapturaPeso,
		@IdDireccion AS IdDireccion,
		(SELECT [Description] FROM dbo.MasterTable WHERE IdTable = 53 AND IdColumn = @IdDireccion) AS Direccion,
		0 AS IdReWeighing,
		'-' AS CardId,
		'-' AS Pila,
		0 AS TareWeight,
		0 AS IdVehicle,
		'-' AS TruckPlate,
		'-' AS Product,
		0 AS GrossWeight,
		'-' AS TrailerPlate,
		'-' AS Quality,
		0 AS NetWeight,
		0 AS InstructedWeight,
		0 AS ReWeight,
		0 AS ToReWeigh,
		0 AS Lotization,
		0 AS Advance,
		0 AS LotToClose,
		0 AS LotSize,
		0 AS DesTare,
		0 AS TareWeightMin,
		0 AS GrossWeightMin,
		0 AS [BatchSize],
		0 AS BatchSizeTolerance,
		0 AS BatchSizeAcumulate,
		CAST(1 AS BIT) AS TareFlag
	END
END
ELSE
BEGIN
	SELECT
	@IdEstadoAutorizado AS IdEstadoAutorizado,
	(SELECT [Description] FROM dbo.MasterTable WHERE IdTable = 51 AND IdColumn = @IdEstadoAutorizado) AS EstadoAutorizado,
	@IdCapturaPeso AS IdCapturaPeso,
	(SELECT [Description] FROM dbo.MasterTable WHERE IdTable = 52 AND IdColumn = @IdCapturaPeso) AS CapturaPeso,
	@IdDireccion AS IdDireccion,
	(SELECT [Description] FROM dbo.MasterTable WHERE IdTable = 53 AND IdColumn = @IdDireccion) AS Direccion,
	0 AS IdReWeighing,
	'-' AS CardId,
	'-' AS Pila,
	0 AS TareWeight,
	0 AS IdVehicle,
	'-' AS TruckPlate,
	'-' AS Product,
	0 AS GrossWeight,
	'-' AS TrailerPlate,
	'-' AS Quality,
	0 AS NetWeight,
	0 AS InstructedWeight,
	0 AS ReWeight,
	0 AS ToReWeigh,
	0 AS Lotization,
	0 AS Advance,
	0 AS LotToClose,
	0 AS LotSize,
	0 AS DesTare,
	0 AS TareWeightMin,
	0 AS GrossWeightMin,
	0 AS [BatchSize],
	0 AS BatchSizeTolerance,
	0 AS BatchSizeAcumulate,
	CAST(1 AS BIT) AS TareFlag
END

GO

CREATE FUNCTION [dbo].[CustomCalculation] (@baseValue INT, @x INT)
RETURNS INT
AS
BEGIN
    DECLARE @result INT;

    IF @x < @baseValue
        --SET @result = @baseValue - @x;
        SET @result = @x;
    ELSE
        SET @result = ABS(@baseValue - @x) --/ 2;

    RETURN @result;
END;
GO